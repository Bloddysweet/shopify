# the line — export

A producer/critic production line for vertical animated shots. Seven agents, thirteen stages, nine
code gates, and a test for every gate. This export is the whole pipeline plus one real shot to test
against.

Gate set **`2026-10-27.5`**.

---

## Install

Node **18 or newer** (built and tested on 20.20.2).

```bash
npm install                                # puppeteer, ffmpeg-static, ffprobe-static, pngjs
npx puppeteer browsers install chrome      # if puppeteer did not download it during install
node pipeline/run.mjs doctor               # checks node, deps, ffmpeg, a real browser launch
```

`node_modules/` is deliberately not shipped — run `npm install` first.

## First three commands

```bash
node pipeline/run.mjs test                          # 17 gate tests — must be 17/17
node pipeline/run.mjs status shorts/t01-transformer-wait
node pipeline/run.mjs all    shorts/t01-transformer-wait
```

`all` runs the gate tests first and refuses to start if any gate has stopped catching its own case. On
the included shot it prints five green gates and then **REJECT at `figures`**:

```
✗ line l6 says 50 and nothing on screen stands on 50 while it is said
```

That is the real state of that shot, not a broken export. It is the case the `figures` gate was
written for.

---

## What is in here

```
pipeline/
  run.mjs                     the command runner: new · status · next · all · run · submit ·
                              approve · override · reject · test · doctor · board
  lib/
    ladder.mjs                the stage table (id, owner, kind, order) + GATE_VERSION + staleness
    spec.mjs                  spec loading, the schema check, and the hand-written spec rules
  schema/spec.schema.json     the authoritative spec schema (additionalProperties: false)
  gates/
    lib.mjs                   shared: openShot, safeBox, sampleTimes, verdict, F, ROOT_DIR
    contract.mjs              the page contract — the six hooks every other gate measures through,
                              plus: every local file the page points at must exist, and fonts must load
    voice.mjs                 the words: banned list, length, repeats, unsourced numbers, overlaps
    frame.mjs                 margins, fragment count, fragments-not-sentences, text on text
    scene.mjs                 allowed objects, serving a line, overlap, count behaviour
    figures.mjs               every spoken number is on screen (exports numbersIn)
    motion.mjs                cuts, pops, dead holds, undeclared/fast/hunting camera
    sound.mjs                 levels, silent tail, lines that start in silence
    render.mjs                frame-by-frame render → x264
  tests/
    run-tests.mjs             the 17-case gate suite
    fixtures/                 pages and specs that each break exactly one rule
  templates/screen.html       the scaffold `new` copies: contract already satisfied
  agents/                     the seven agent briefs (00-director … 60-encode)
  PAGE.md                     the page contract, in prose
  PIPELINE.md                 the detailed reference — every gate, every finding string
  README.md                   the overview
  NOTES.md                    what moved and why; what the gates found on first real run
  USAGE.txt                   the command list
  attic/critic.mjs            the old score-based critic, kept as a warning
internet/fonts/               the woff2 faces the drawings use (Space Grotesk, JetBrains Mono)
shorts/t01-transformer-wait/  one finished shot, used as the test case
reference/                    DESIGN.md, RESEARCH.md, WORKFLOW.md from the original project
package.json                  engines + deps + convenience scripts
MANIFEST.txt                  every file, with size and a sha256 prefix
```

### The test-case shot

`shorts/t01-transformer-wait/` is self-contained **except for the fonts**: its drawing is
`screen.html` inside the folder, its mix is `audio/track.wav` inside the folder, and the three woff2
faces are in `internet/fonts/` at the repo root — keep that folder at the same relative path and the
page resolves. The contract gate now names any file a page points at that is not there, so a drawing
can never quietly fall back to a system font and have its margins measured in the wrong typeface.

```
t01-transformer-wait.spec.json   1080×1920, 28.0 s, 8 lines, a 128-week count
screen.html                      the drawing, contract satisfied
ledger.json                      what passed, under which gate version, on which hashes
reports/*.txt                    each gate's own words
verdicts/{reading,rhythm}.json   the two signed judgement gates
evidence/l-l1..l8.png            one frame per line, at the middle of the line
report.html                      the gate board with the evidence embedded
audio/                           the eight line files and the mixed track
```

Not included, to keep the zip small: the encoded `.mp4` (1.3 MB), the music bed (`bed.wav`, 4.8 MB,
not referenced by the spec), and the contact-sheet stills.

---

## The three things worth knowing before you change anything

**1. A pass expires.** Every pass records `gateVersion`, `specHash` and `srcHash`. Change a gate, the
spec, or the drawing and the pass goes stale — `status` prints `↺ the spec changed since this passed`.
So when you bump `GATE_VERSION` in `lib/ladder.mjs`, expect the included shot to go stale and be
re-earned. That is the design, not a bug.

**2. Judgement gates cannot be run.** `reading` (owner: image-critic) and `rhythm` (owner:
motion-critic) only move on a signed verdict:

```json
{ "stage": "reading", "agent": "image-critic", "verdict": "PASS", "summary": "…", "findings": [] }
```

`submit` refuses a verdict signed by anyone else, for a stage that is code, or while an earlier stage
is open.

**3. Adding a gate needs a test.** Write `gates/<name>.mjs` returning `verdict(stage, findings, report)`;
read every limit from the spec, never from a constant; insert the stage in `lib/ladder.mjs`; add a
fixture that breaks the rule and a case in `tests/run-tests.mjs`; bump `GATE_VERSION`. If the gate
cannot be made to fail on purpose, it is not a gate.

---

## Troubleshooting

**`Failed to launch the browser process` / `error while loading shared libraries: libnspr4.so`.**
Headless Chrome needs system libraries on a bare Linux image:

```bash
npx puppeteer browsers install chrome --install-deps     # needs root
```

Without root, fetch the missing debs, unpack them with `dpkg-deb -x` and point `LD_LIBRARY_PATH` at
the unpacked `usr/lib/x86_64-linux-gnu`.

**`Cannot find package 'ffmpeg-static'`.** `npm install` did not run, or ran in the wrong directory.

**`the page points at a file that is not there: ../../internet/fonts/…`.** A page's relative paths
resolve from the page, not from the pipeline. Ship the font/asset at that path, or inline it as a
data URI.

**A gate reports `__ready` never true.** The page never finished setting up — usually a font that
cannot load. Set `__ready` only after `document.fonts.ready`.

**Everything is stale after `git pull`.** Check `GATE_VERSION` in `lib/ladder.mjs`, then re-run `all`.
