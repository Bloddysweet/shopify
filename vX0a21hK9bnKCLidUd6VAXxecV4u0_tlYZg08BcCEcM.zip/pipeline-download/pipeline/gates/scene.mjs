/* scene.mjs — the critic that reads the SCENE, not the pixels.
   The pixel critics could not see four invented dots, or a hundred houses tiled on top of
   each other. This one asks the page what it drew: every visible object, its parent, which
   audio line it serves, and its box. Then it holds those against the beat's brief.

      It is a CLI: page + a map file that pipeline/lib/ladder.mjs builds out of the shot spec. The map
   carries the safe box, the line list and the count target, so the safe box is defined in ONE place
   for every critic — the disagreement between three critics about the same picture came from each
   of them carrying its own copy of these numbers.

   node pipeline/gates/scene.mjs shorts/<shot>/screen.html shorts/<shot>/derived/scene.json   */
import puppeteer from 'puppeteer';
import path from 'node:path';
import fs from 'node:fs';

const [,, FILE, MAPFILE] = process.argv;
const MAP = JSON.parse(fs.readFileSync(MAPFILE, 'utf8'));
const STEP = MAP.sample || 0.1;

const browser = await puppeteer.launch({
  args: ['--no-sandbox', '--disable-dev-shm-usage', '--font-render-hinting=none']
});
const page = await browser.newPage();
const VP = MAP.viewport || { w: 1300, h: 740 };
await page.setViewport({ width: VP.w, height: VP.h, deviceScaleFactor: 1 });
await page.goto('file://' + path.resolve(FILE), { waitUntil: 'load' });
await page.waitForFunction('window.__ready===true');
await page.evaluate(() => document.fonts.ready);
const total = await page.evaluate(() => window.__total());

const frames = [];
for (let t = 0; t <= total + 1e-9; t += STEP) {
  const T = +t.toFixed(3);
  frames.push({ t: T, ...(await page.evaluate(x => window.__audit(x), T)) });
}
await browser.close();

const problems = [];
const seen = new Set();
const add = (rule, t0, t1, detail) => {
  const k = rule + '|' + Math.round(t0 * 2) + '|' + (detail || '').slice(0, 24);
  if (seen.has(k)) return;
  seen.add(k);
  problems.push({ rule, t0, t1, detail });
};

/* ---- 1. nothing on screen that the brief does not allow ---- */
for (const f of frames) {
  for (const o of f.objects) {
    if (!f.whitelist.includes(o.name))
      add('NOT IN THE BRIEF', f.t, f.t, `${o.name} (allowed: ${f.whitelist.join(', ')})`);
    if (!o.serves)
      add('OBJECT SERVES NO LINE', f.t, f.t, o.name);
  }
  /* every object must serve a line the beat map actually contains */
  for (const o of f.objects) {
    if (o.serves && MAP.lines && !MAP.lines.some(l => l.id === o.serves))
      add('SERVES A LINE THAT DOES NOT EXIST', f.t, f.t, `${o.name} → ${o.serves}`);
  }
}

/* ---- 2. two objects may not occupy the same space, unless one is inside the other ---- */
const overlapPx = (a, b) => {
  const ox = Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0);
  const oy = Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0);
  return ox > 1.5 && oy > 1.5 ? ox * oy : 0;
};
for (const f of frames) {
  const objs = f.objects;
  for (let i = 0; i < objs.length; i++) {
    for (let j = i + 1; j < objs.length; j++) {
      const a = objs[i], b = objs[j];
      if (a.parent === b.name || b.parent === a.name) continue;   /* containment is fine */
      if (a.name === 'street' || b.name === 'street') continue;   /* the grid is a container */
      if (a.name === 'dimension' || b.name === 'dimension') continue;
      const area = overlapPx(a, b);
      if (area > (MAP.overlap_max_px || 260))
        add('OBJECTS OVERLAP', f.t, f.t, `${a.name} × ${b.name} ${Math.round(area)} px²`);
    }
  }
}

/* ---- 3. a count has to count: monotone, and it has to arrive one at a time ---- */
if (MAP.count) {
  const { object, from, to, target, max_jump } = MAP.count;
  let prev = 0, lastT = null;
  for (const f of frames) {
    if (f.t < from || f.t > to) continue;
    const n = f.objects.filter(o => o.name === object).length;
    if (n < prev) add('COUNT GOES BACKWARDS', f.t, f.t, `${prev} → ${n}`);
    if (lastT !== null && n - prev > (max_jump || 4))
      add('COUNT JUMPS', lastT, f.t, `${prev} → ${n} in ${STEP}s`);
    prev = n; lastT = f.t;
  }
  /* the target is checked when the count is DUE, not at the end of the shot: what happens
     to the objects afterwards (a deliberate closing dim, say) is the close's business. */
  const atEnd = frames.find(f => f.t >= to) || frames[frames.length - 1];
  const endN = atEnd.objects.filter(o => o.name === object).length;
  if (endN < target) add('COUNT NEVER REACHES ITS TARGET', to, to, `${endN} of ${target}`);
}

/* ---- 4. text: fragments only, inside the safe area, on quiet ground ---- */
const SAFE = MAP.safe || { l: 40, r: 1240, t: 28, b: 672 };
/* `chrome` is the sheet's running head — the brand mark set in the margin of every frame.
   It is part of the paper, not a fragment, so it does not count against the three-fragment rule. */
const CHROME = new Set(MAP.chrome || []);
for (const f of frames) {
  const texts = (f.texts || []).filter(s => !CHROME.has(String(s).trim()));
  if (texts.length > (MAP.max_texts || 3))
    add('TOO MANY TEXT FRAGMENTS', f.t, f.t, `${texts.length} on screen`);
  for (const t of texts) {
    const r = (f.textBoxes || []).find(b => String(b.s).trim() === String(t).trim());
    if (r && (r.x0 < SAFE.l - 0.5 || r.x1 > SAFE.r + 0.5 || r.y0 < SAFE.t - 0.5 || r.y1 > SAFE.b + 0.5))
      add('TEXT OUTSIDE THE FRAME MARGIN', f.t, f.t, `${t} ${[r.x0, r.y0, r.x1, r.y1].map(v => Math.round(v)).join(',')}`);
  }
}

/* ---- report ---- */
const L = [];
L.push(`SCENE CRITIC — ${path.basename(FILE)}`);
L.push(`${frames.length} samples every ${STEP}s · ${problems.length} finding(s)`);
L.push('');
for (const p of problems) {
  const rng = p.t1 !== p.t0 ? `${p.t0.toFixed(1)}–${p.t1.toFixed(1)}s` : `${p.t0.toFixed(1)}s`;
  L.push(`${rng}  ✗ ${p.rule}${p.detail ? ' — ' + p.detail : ''}`);
}
/* a shape-of-the-timeline line, so the judgement can be checked */
const objLine = frames.filter((_, i) => i % Math.round(1 / STEP) === 0)
  .map(f => `${Math.round(f.t)}s:${f.objects.length}`).join(' ');
L.push('');
L.push(`objects on screen per second: ${objLine}`);
L.push('');
L.push(problems.length ? 'VERDICT: REJECTED — the scene does not match the brief'
                        : 'VERDICT: PASSED — every object is in the brief, serves a line, and holds its space');
fs.writeFileSync(path.join(path.dirname(MAPFILE), 'scene-report.txt'), L.join('\n'));
console.log(L.join('\n'));
process.exit(problems.length ? 1 : 0);
