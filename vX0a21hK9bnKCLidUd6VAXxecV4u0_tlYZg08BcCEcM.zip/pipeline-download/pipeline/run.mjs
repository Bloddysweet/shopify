#!/usr/bin/env node
/* pipeline/run.mjs — the production line, enforced.

   node pipeline/run.mjs all      <shotDir>                 the whole line, stops at the first wall
   node pipeline/run.mjs status   <shotDir>
   node pipeline/run.mjs next     <shotDir>
   node pipeline/run.mjs run      <shotDir> <stage>          code gates only
   node pipeline/run.mjs submit   <shotDir> <stage> <file>   judgement gates only
   node pipeline/run.mjs approve  <shotDir> still "<quote>"  the user's gate
   node pipeline/run.mjs override <shotDir> <stage> "<why>"  encode ahead of a gate, on the record
   node pipeline/run.mjs reject   <shotDir> <stage> "<why>"  send work back to a gate

   A stage may not run until every earlier stage has passed. Judgement gates cannot be generated
   by this tool: only a signed verdict file passes them. A pass is bound to a hash of the spec,
   a hash of the drawing, and the version of the gate that granted it. */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import ffmpegPath from 'ffmpeg-static';
import { loadSpec, validateSpec } from './lib/spec.mjs';
import { STAGES, byId, stageIndex, GATE_VERSION } from './lib/ladder.mjs';

const ROOT = path.resolve(new URL('../', import.meta.url).pathname);
const [,, cmd, shotArg, ...rest] = process.argv;
const NO_SHOT = ['test', 'doctor', 'board'];
if (!cmd || (!NO_SHOT.includes(cmd) && !shotArg)) { console.log(fs.readFileSync(new URL('./USAGE.txt', import.meta.url), 'utf8')); process.exit(2); }

/* `test` needs no shot: it tests the gates themselves. */
if (cmd === 'test') {
  const r = spawnSync(process.execPath, ['pipeline/tests/run-tests.mjs'], { cwd: ROOT, encoding: 'utf8' });
  process.stdout.write(r.stdout || ''); process.stderr.write(r.stderr || '');
  process.exit(r.status ?? 1);
}

const shotDir = path.resolve(ROOT, shotArg || '.');
const ledgerFile = path.join(shotDir, 'ledger.json');
const C = { g: '\x1b[32m', r: '\x1b[31m', y: '\x1b[33m', d: '\x1b[2m', x: '\x1b[0m', b: '\x1b[1m' };

/* ------------------------------------------------------------------ ledger */
const readLedger = () => fs.existsSync(ledgerFile) ? JSON.parse(fs.readFileSync(ledgerFile, 'utf8'))
  : { shot: path.basename(shotDir), updated: null, stages: {}, approvals: {}, rejections: [], overrides: {} };
function writeLedger(l) { l.updated = new Date().toISOString(); fs.writeFileSync(ledgerFile, JSON.stringify(l, null, 2)); }
function writeReport(stage, text) {
  const dir = path.join(shotDir, 'reports');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, `${stage}.txt`), text || '');
}

const sha = f => crypto.createHash('sha1').update(fs.readFileSync(f)).digest('hex').slice(0, 10);

function context() {
  const { file, id, spec } = loadSpec(shotDir);
  const srcFile = spec.src && path.join(ROOT, spec.src);
  return {
    shotDir, spec, specFile: file,
    specFindings: validateSpec(spec, id),
    specHash: sha(file),
    srcHash: srcFile && fs.existsSync(srcFile) ? sha(srcFile) : null
  };
}

const state = (l, id) => l.stages[id]?.state || 'pending';
const isPass = (l, id) => ['passed', 'approved'].includes(state(l, id));

/* A pass is only a pass for the picture it was earned on, under the gate that granted it. */
function staleReason(l, id, ctx) {
  const e = l.stages[id];
  if (!e || !isPass(l, id)) return null;
  if (e.gateVersion && e.gateVersion !== GATE_VERSION && id !== 'spec' && id !== 'image')
    return 'the gate has changed since this passed';
  if (e.specHash && e.specHash !== ctx.specHash) return 'the spec changed since this passed';
  if (id !== 'spec' && e.srcHash && ctx.srcHash && e.srcHash !== ctx.srcHash) return 'the drawing changed since this passed';
  return null;
}

function openStages(l, ctx, uptoIndex = STAGES.length) {
  return STAGES.slice(0, uptoIndex).filter(s => !isPass(l, s.id) || staleReason(l, s.id, ctx));
}

/* ------------------------------------------------------------------ running one code gate */
async function runCodeStage(stage, l, ctx, { quiet = false } = {}) {
  const action = stage.produce || stage.run;
  const res = await action(ctx);
  writeReport(stage.id, `${res.report || ''}\n${(res.findings || []).map(f => `✗ ${f.what}`).join('\n')}`);
  l.stages[stage.id] = {
    state: res.ok ? 'passed' : 'failed', owner: stage.owner, kind: stage.kind,
    at: new Date().toISOString(), gateVersion: GATE_VERSION,
    specHash: ctx.specHash, srcHash: ctx.srcHash,
    findings: res.findings || [], product: res.product || null, report: `reports/${stage.id}.txt`
  };
  writeLedger(l);
  if (!quiet) {
    console.log(`${res.ok ? C.g + 'PASSED  ' + C.x : C.r + 'REJECTED' + C.x}  ${stage.id} · ${stage.name}  ${C.d}${(res.findings || []).length} finding(s)${C.x}`);
    for (const f of res.findings || []) console.log(`   ${C.r}✗${C.x} ${f.what}${f.fix ? `\n     ${C.d}→ ${f.fix}${C.x}` : ''}`);
  }
  return res;
}

/* ------------------------------------------------------------------ the human-readable report */
async function buildReport(l, ctx) {
  const spec = ctx.spec;
  const evDir = path.join(shotDir, 'evidence');
  fs.mkdirSync(evDir, { recursive: true });

  /* one frame per line, taken at the middle of the line: the critic's evidence pack */
  let shots = [];
  try {
    const puppeteer = (await import('puppeteer')).default;
    const b = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage', '--font-render-hinting=none'] });
    const p = await b.newPage();
    await p.setViewport({ width: spec.frame.w, height: spec.frame.h, deviceScaleFactor: 1 });
    await p.goto('file://' + path.join(ROOT, spec.src), { waitUntil: 'load' });
    await p.waitForFunction('window.__ready===true');
    await p.evaluate(() => document.fonts.ready);
    for (const line of spec.lines || []) {
      const t = +(line.in + (line.trim[1] - line.trim[0]) / 2).toFixed(2);
      await p.evaluate(x => window.__draw(x), t);
      const f = `l-${line.v}.png`;
      const full = path.join(evDir, f);
      await p.screenshot({ path: full, type: 'png' });
      /* the report has to open in a viewer with no network and no local files, so the evidence is
         carried inside the html as a thumbnail. The full-size png stays in evidence/ for a person. */
      const thumb = path.join(evDir, `l-${line.v}.thumb.jpg`);
      spawnSync(ffmpegPath, ['-y', '-loglevel', 'error', '-i', full, '-vf', 'scale=300:-2', '-q:v', '6', thumb]);
      const uri = fs.existsSync(thumb) ? `data:image/jpeg;base64,${fs.readFileSync(thumb).toString('base64')}` : null;
      shots.push({ v: line.v, t, file: `evidence/${f}`, uri, text: line.text });
    }
    await b.close();
  } catch (e) { shots = []; }

  const esc = s => String(s).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]));
  const rows = STAGES.map(s => {
    const st = state(l, s.id);
    const stl = staleReason(l, s.id, ctx);
    const mark = stl ? '↺' : st === 'passed' ? 'pass' : st === 'approved' ? 'approved by user'
      : st === 'failed' ? 'FAILED' : '—';
    const cls = stl ? 'stale' : st === 'passed' ? 'pass' : st === 'approved' ? 'ok' : st === 'failed' ? 'fail' : 'idle';
    const f = (l.stages[s.id]?.findings || []).map(x => `<li>${esc(x.what)}${x.fix ? `<div class="fix">${esc(x.fix)}</div>` : ''}</li>`).join('');
    return `<tr class="${cls}"><td>${s.id}</td><td>${esc(s.name)}</td><td>${s.owner}</td><td>${mark}${stl ? `<div class="fix">${esc(stl)}</div>` : ''}</td>
      <td>${f ? `<ul>${f}</ul>` : ''}</td></tr>`;
  }).join('\n');

  const evidence = shots.map(s => `<figure><img src="${s.uri || s.file}"><figcaption><b>${s.v}</b> · ${s.t}s<br><span>“${esc(s.text)}”</span></figcaption></figure>`).join('\n');
  const open = openStages(l, ctx);
  const next = open[0];

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(l.shot)} · report</title>
<style>
 body{background:#0A0B0D;color:#E9E5DC;font:14px/1.5 ui-sans-serif,system-ui,sans-serif;margin:0;padding:40px 36px 80px}
 h1{font-size:26px;margin:0 0 4px;letter-spacing:-.02em} .sub{color:#8C887F;margin-bottom:28px}
 table{border-collapse:collapse;width:100%;margin-bottom:34px} td{border-top:1px solid #1c2026;padding:9px 10px;vertical-align:top}
 td:first-child{font-family:ui-monospace,monospace;color:#8C887F;width:70px}
 .pass td{color:#cfcbc2} .fail{background:#2a1113} .stale{background:#2a2410} .ok{background:#12200f} .idle td{color:#5a5650}
 ul{margin:0;padding-left:16px} .fix{color:#8C887F;font-size:12px}
 h2{font-size:15px;text-transform:uppercase;letter-spacing:.16em;color:#8C887F;margin:34px 0 12px}
 figure{display:inline-block;width:190px;margin:0 12px 16px 0;vertical-align:top}
 figure img{width:100%;border:1px solid #1c2026;border-radius:4px}
 figcaption{font-size:12px;color:#8C887F;margin-top:6px} figcaption span{color:#cfcbc2}
 .next{font-size:16px;padding:14px 16px;border:1px solid #FF5A1F;border-radius:6px;margin-bottom:30px}
 .next b{color:#FF5A1F}
</style></head><body>
<h1>${esc(l.shot)}</h1>
<div class="sub">${esc(spec.format)} ${spec.frame.w}×${spec.frame.h} · ${spec.duration || '—'}s · gate set ${GATE_VERSION} · updated ${esc(l.updated || '—')}</div>
${next ? `<div class="next">next: <b>${next.id}</b> — ${esc(next.name)} <span class="sub">(${next.owner}, ${next.kind})</span></div>` : '<div class="next">every gate passed</div>'}
<h2>gates</h2>
<table>${rows}</table>
<h2>the lines, and the frame at each</h2>
<div>${evidence || '<span class="sub">no evidence captured</span>'}</div>
<h2>waivers and overrides</h2>
<ul>${(spec.waivers || []).map(w => `<li><b>${esc(w.gate)}</b> — ${esc(w.what)}<div class="fix">${esc(w.why)}</div></li>`).join('') || '<li class="sub">none</li>'}
${Object.entries(l.overrides || {}).map(([k, v]) => `<li><b>override · ${esc(k)}</b> — ${esc(v.reason)}</li>`).join('')}</ul>
</body></html>`;
  fs.writeFileSync(path.join(shotDir, 'report.html'), html);
  return path.join(shotDir, 'report.html');
}

/* ------------------------------------------------------------------ printing */
function printStatus(l, ctx) {
  const spec = ctx?.spec;
  console.log(`\n${C.b}${l.shot}${C.x} ${C.d}${spec ? spec.shot : ''}${C.x}\n`);
  for (const s of STAGES) {
    const st = state(l, s.id);
    const stl = ctx ? staleReason(l, s.id, ctx) : null;
    const mark = stl ? `${C.y}↺${C.x}` : st === 'passed' ? `${C.g}✓${C.x}` : st === 'approved' ? `${C.g}✓ user${C.x}`
      : st === 'failed' ? `${C.r}✗${C.x}` : `${C.d}·${C.x}`;
    const n = l.stages[s.id]?.findings?.length || 0;
    console.log(`  ${mark} ${s.id.padEnd(9)} ${s.name.padEnd(48)} ${C.d}${s.owner} · ${s.kind}${C.x}${n ? `  ${C.r}${n} finding(s)${C.x}` : ''}${stl ? `  ${C.y}${stl}${C.x}` : ''}`);
  }
  const open = ctx ? openStages(l, ctx) : STAGES.filter(s => !isPass(l, s.id));
  console.log(`\n  ${C.b}next:${C.x} ${open[0] ? `${open[0].id} — ${open[0].name} ${C.d}(${open[0].owner}, ${open[0].kind})${C.x}` : `${C.g}done${C.x}`}`);
  if (open[0] && open[0].kind !== 'code') console.log(`  ${C.d}this gate belongs to ${open[0].owner}; the pipeline cannot pass it for them${C.x}`);
  console.log('');
}

/* ------------------------------------------------------------------ commands */
/* ------------------------------------------------------------------ new: start a shot */
if (cmd === 'new') {
  const id = path.basename(shotDir);
  if (fs.existsSync(path.join(shotDir, `${id}.spec.json`))) {
    console.error(`${C.r}refused${C.x} — ${shotDir} already has a spec; a shot is never started twice`);
    process.exit(1);
  }
  const TOTAL = 6, W = 1080, H = 1920;
  for (const d of ['audio', 'derived', 'reports', 'evidence', 'verdicts']) fs.mkdirSync(path.join(shotDir, d), { recursive: true });

  const tpl = fs.readFileSync(path.join(ROOT, 'pipeline/templates/screen.html'), 'utf8')
    .replaceAll('__SHOT__', id).replaceAll('__W__', String(W)).replaceAll('__H__', String(H))
    .replaceAll('__TOTAL__', String(TOTAL));
  fs.writeFileSync(path.join(shotDir, 'screen.html'), tpl);

  const spec = {
    shot: id, scaffold: true, format: 'vertical', duration: TOTAL,
    src: path.relative(ROOT, path.join(shotDir, 'screen.html')),
    palette: 'DESIGN.md',
    sound: { track: path.relative(ROOT, path.join(shotDir, 'audio/track.wav')), target_lufs: -16 },
    frame: { w: W, h: H, margin: { l: 72, r: 72, t: 56 }, safe_b: 1690 },
    lines: [{ v: 'l1', text: 'Replace this with the first sentence of the shot.', file: '', trim: [0, 1], in: 0.2 }],
    objects: [{ name: 'object', projection: 'elevation', serves: ['l1'],
                reads_without_caption: 'Say in words what a stranger sees, with no caption.' }],
    whitelist: ['object'],
    beats: [
      { t: 0.2, what: 'the fragment arrives', why: 'l1 starts at 0.20' },
      { t: 1.2, what: 'the object arrives', why: 'the line names it' },
      { t: TOTAL - 0.6, what: 'closing state, held', why: 'the shot resolves and holds' }
    ],
    gates: { mechanical: { safe: 'v', max_texts: 3, max_words: 3, chrome: [] },
             semantic: { invented: 0, abstract_standins: 0, projections_per_object: 1 },
             rhythm: { change_every: [2, 4], transform_every: [5, 8], holds_max: 2.0 },
             motion: { cuts: [], zoom: [] } },
    waivers: [], sources: [],
    approval: { still: null, approved_by: null, quote: null, date: null, state: 'draft' }
  };
  fs.writeFileSync(path.join(shotDir, `${id}.spec.json`), JSON.stringify(spec, null, 2) + '\n');
  writeLedger({ shot: id, updated: null, stages: {}, approvals: {}, rejections: [], overrides: {} });

  console.log(`\n${C.g}created${C.x} ${path.relative(ROOT, shotDir)}`);
  console.log(`  ${id}.spec.json   ${C.d}scaffold: true — the spec gate will refuse it until you write the shot${C.x}`);
  console.log(`  screen.html      ${C.d}the page contract, satisfied (pipeline/PAGE.md)${C.x}`);
  console.log(`\n  ${C.d}next: fill in the lines and the objects, draw the thing, then delete "scaffold": true${C.x}`);
  console.log(`  ${C.d}      node pipeline/run.mjs all ${path.relative(ROOT, shotDir)}${C.x}\n`);
  process.exit(0);
}

/* ------------------------------------------------------------------ doctor: is this machine able to run the line */
if (cmd === 'doctor') {
  const checks = [];
  const add = (name, ok, detail) => checks.push({ name, ok, detail });

  add('node', parseInt(process.versions.node) >= 18, `v${process.versions.node}`);
  for (const dep of ['puppeteer', 'pngjs', 'ffmpeg-static']) {
    const p = path.join(ROOT, 'node_modules', dep);
    add(dep, fs.existsSync(p), fs.existsSync(p) ? 'installed' : 'missing — npm install ' + dep);
  }
  const ff = spawnSync(ffmpegPath, ['-version'], { encoding: 'utf8' });
  add('ffmpeg', ff.status === 0, (ff.stdout || '').split('\n')[0] || 'not runnable');

  let browserOk = false, why = '';
  try {
    const puppeteer = (await import('puppeteer')).default;
    const b = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
    const p = await b.newPage();
    await p.setContent('<body style="font:700 40px sans-serif">ok</body>');
    browserOk = (await p.evaluate(() => document.fonts.status)) === 'loaded';
    why = 'launched, fonts loaded';
    await b.close();
  } catch (e) { why = String(e.message || e).slice(0, 120); }
  add('puppeteer', browserOk, why);

  if (fs.existsSync(path.join(shotDir, 'ledger.json'))) {
    try {
      const ctx = context();
      add('spec', ctx.specFindings.length === 0, ctx.specFindings.map(f => f.what).join(' · ') || 'legal');
      add('drawing', !!ctx.srcHash, ctx.spec.src || 'no src');
    } catch (e) { add('spec', false, String(e.message || e).slice(0, 120)); }
  }

  console.log('');
  for (const c of checks) console.log(`  ${c.ok ? C.g + '✓' + C.x : C.r + '✗' + C.x} ${c.name.padEnd(12)} ${C.d}${c.detail}${C.x}`);
  const bad = checks.filter(c => !c.ok).length;
  console.log(`\n  ${bad ? C.r + bad + ' problem(s)' + C.x : C.g + 'this machine can run the line' + C.x}\n`);
  process.exit(bad ? 1 : 0);
}

/* ------------------------------------------------------------------ the board: every shot at once */
if (cmd === 'board') {
  const found = [];
  const walk = dir => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (['node_modules', '.git', 'pipeline', 'derived', 'evidence', 'reports', 'audio', 'build', 'verdicts', 'stills'].includes(e.name)) continue;
      const p = path.join(dir, e.name);
      if (!e.isDirectory()) continue;
      const spec = path.join(p, `${e.name}.spec.json`);
      if (fs.existsSync(spec)) found.push(p);
      else walk(p);
    }
  };
  walk(ROOT);

  const esc = x => String(x).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]));
  const rows = found.map(dir => {
    const { spec, id } = (() => { const r = loadSpec(dir); return { spec: r.spec, id: r.id }; })();
    const l = fs.existsSync(path.join(dir, 'ledger.json')) ? JSON.parse(fs.readFileSync(path.join(dir, 'ledger.json'), 'utf8')) : { stages: {} };
    const ctx = { spec, specHash: 'x', srcHash: null };
    const marks = STAGES.map(st => {
      const e = l.stages?.[st.id];
      const done = ['passed', 'approved'].includes(e?.state);
      const cls = !e ? 'idle' : done ? (st.kind === 'code' ? 'pass' : 'ok') : 'fail';
      const label = !e ? '·' : done ? (st.kind === 'code' ? '✓' : '✓*') : '✗';
      return `<td class="${cls}" title="${esc(st.id)}">${label}</td>`;
    }).join('');
    const open = STAGES.find(st => !['passed', 'approved'].includes(l.stages?.[st.id]?.state));
    return `<tr><td><b>${esc(id)}</b></td><td class="d">${esc(spec.format)} ${spec.frame.w}×${spec.frame.h} · ${spec.duration}s</td>
      ${marks}<td class="d">${open ? `${esc(open.id)} <span class="o">(${open.owner})</span>` : 'locked'}</td>
      <td><a href="${esc(path.relative(ROOT, path.join(dir, 'report.html')))}">report</a></td></tr>`;
  }).join('\n');

  const head = STAGES.map(st => `<td title="${esc(st.name)}">${esc(st.id.slice(0, 4))}</td>`).join('');
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>the line · board</title>
<style>
 body{background:#0A0B0D;color:#E9E5DC;font:14px/1.6 ui-sans-serif,system-ui,sans-serif;margin:0;padding:40px 36px}
 h1{font-size:24px;margin:0 0 4px} .sub{color:#8C887F;margin-bottom:26px;font-size:13px}
 table{border-collapse:collapse;width:100%} td,th{border-bottom:1px solid #1c2026;padding:8px 6px;text-align:center}
 td:first-child,td:nth-child(2){text-align:left} th{color:#8C887F;font-weight:500;font-size:11px;letter-spacing:.1em;text-transform:uppercase}
 .pass{color:#8fbf7f}.ok{color:#3fbf8f}.fail{color:#ff6b5a;background:#2a1113}.idle{color:#3a3a3a}
 .d{color:#8C887F;font-size:12px} .o{color:#FF5A1F} a{color:#E9E5DC}
</style></head><body>
<h1>the line</h1>
<div class="sub">gate set ${GATE_VERSION} · ${found.length} shot(s) · ✓ code pass · ✓* signed verdict · ✗ failed · · open</div>
<table><tr><th>shot</th><th></th>${head}<th>next</th><th></th></tr>
${rows}
</table></body></html>`;
  const out = path.join(ROOT, 'pipeline/report.html');
  fs.writeFileSync(out, html);
  console.log(`\n  ${found.length} shot(s) · ${path.relative(ROOT, out)}\n`);
  process.exit(0);
}

if (cmd === 'status') { const l = readLedger(); let ctx = null; try { ctx = context(); } catch {} printStatus(l, ctx); process.exit(0); }

if (cmd === 'next') {
  const l = readLedger(); const ctx = context();
  const n = openStages(l, ctx)[0];
  console.log(n ? `${n.id}\t${n.owner}\t${n.kind}` : 'done'); process.exit(0);
}

/* A gate that is not tested is an opinion. Before the line runs, prove the gates still catch
   the failures they were written for — otherwise a green board means nothing. */
function gateSuite({ quiet }) {
  const r = spawnSync(process.execPath, ['pipeline/tests/run-tests.mjs'], { cwd: ROOT, encoding: 'utf8' });
  if (quiet) return r;
  console.log(r.stdout || '', r.stderr || '');
  return r;
}

if (cmd === 'all') {
  const l = readLedger();
  console.log(`\n${C.b}${l.shot}${C.x} — running the line\n`);
  const suite = gateSuite({ quiet: true });
  const suiteLine = (suite.stdout || '').split('\n').filter(Boolean).pop() || '';
  if (suite.status !== 0) {
    console.log(`${C.r}STOP${C.x}  the gates themselves failed their own tests — nothing below this line is trustworthy`);
    console.log(`${C.d}${(suite.stdout || '').split('\n').filter(l => l.includes('✗')).join('\n')}${C.x}`);
    console.log(`${C.d}run: node pipeline/run.mjs test${C.x}\n`);
    process.exit(1);
  }
  console.log(`${C.d}gates self-tested first${C.x} ${C.d}·${C.x} ${C.d}${suiteLine.trim()}${C.x}\n`);
  for (const stage of STAGES) {
    if (stage.kind !== 'code') {
      console.log(`${C.y}STOP${C.x}  ${stage.id} · ${stage.name}  ${C.d}belongs to ${stage.owner} (${stage.kind}) — the pipeline cannot pass it${C.x}`);
      if (stage.kind === 'user' && stage.id === 'still')
        console.log(`  ${C.d}approve with: run.mjs approve <shot> still "<your words>"${C.x}`);
      else if (stage.id === 'reading' || stage.id === 'rhythm')
        console.log(`  ${C.d}${stage.brief}${C.x}`);
      const f = await buildReport(l, context());
      console.log(`\n  ${C.d}report: ${path.relative(ROOT, f)}${C.x}\n`);
      process.exit(0);
    }
    const ctx = context();
    const blocked = openStages(l, ctx, stageIndex(stage.id)).filter(s => s.kind === 'code');
    if (blocked.length) {
      console.log(`${C.r}STOP${C.x}  ${stage.id} is blocked by ${blocked.map(s => s.id).join(', ')}`);
      const f = await buildReport(l, ctx);
      console.log(`\n  ${C.d}report: ${path.relative(ROOT, f)}${C.x}\n`);
      process.exit(1);
    }
    const res = await runCodeStage(stage, l, ctx);
    if (!res.ok) {
      const f = await buildReport(l, context());
      console.log(`\n  ${C.d}returns to the ${stage.owner} agent · report: ${path.relative(ROOT, f)}${C.x}\n`);
      process.exit(1);
    }
  }
  const f = await buildReport(l, context());
  console.log(`\n${C.g}every code gate passed${C.x} · ${C.d}${path.relative(ROOT, f)}${C.x}`);
  process.exit(0);
}

if (cmd === 'run') {
  const id = rest[0];
  const stage = byId(id);
  if (!stage) { console.error(`no stage ${id}`); process.exit(2); }
  if (stage.kind !== 'code') { console.error(`${id} is a ${stage.kind} gate owned by ${stage.owner}; it cannot be run, only submitted`); process.exit(2); }

  const l = readLedger();
  const ctx = context();
  const waived = sid => id === 'encode' && sid === 'still' && l.overrides && l.overrides.still;
  const blocked = STAGES.slice(0, stageIndex(id)).filter(s => (!isPass(l, s.id) || staleReason(l, s.id, ctx)) && !waived(s.id));
  if (blocked.length) {
    console.error(`${C.r}refused${C.x} — ${id} needs ${blocked.map(s => s.id).join(', ')} passed first`);
    process.exit(1);
  }
  if (id === 'encode' && !isPass(l, 'still')) {
    const ov = l.overrides && l.overrides.still;
    if (!ov) {
      console.error(`${C.r}refused${C.x} — nothing is encoded before the still is approved by the user (gate: still)`);
      console.error(`${C.d}if a file is needed before the answer, declare it: run.mjs override <shot> still "<why>"${C.x}`);
      process.exit(1);
    }
    console.log(`${C.y}OVERRIDDEN${C.x} — encoding ahead of the still gate: "${ov.reason}"`);
    console.log(`${C.d}this file is not locked; if the still is rejected it is discarded${C.x}`);
  }
  const res = await runCodeStage(stage, l, ctx);
  if (!res.ok && stage.owner !== 'user') console.log(`\n  ${C.d}this returns to the ${stage.owner} agent; it does not restart the shot${C.x}`);
  process.exit(res.ok ? 0 : 1);
}

if (cmd === 'submit') {
  const [, , , , id, file] = process.argv;
  const stage = byId(id);
  if (!stage) { console.error(`no stage ${id}`); process.exit(2); }
  if (stage.kind === 'code') { console.error(`${id} is a code gate; run it, do not submit it`); process.exit(2); }
  const v = JSON.parse(fs.readFileSync(path.resolve(file), 'utf8'));
  if (v.stage !== id) { console.error(`verdict is for ${v.stage}, not ${id}`); process.exit(2); }
  if (!['PASS', 'REJECT'].includes(v.verdict)) { console.error('verdict must be PASS or REJECT'); process.exit(2); }
  if (v.agent !== stage.owner) { console.error(`this gate belongs to ${stage.owner}, the verdict is signed ${v.agent}`); process.exit(2); }

  const l = readLedger();
  const ctx = context();
  const before = openStages(l, ctx, stageIndex(id));
  if (before.length) { console.error(`${C.r}refused${C.x} — ${id} needs ${before.map(s => s.id).join(', ')} first`); process.exit(1); }

  fs.mkdirSync(path.join(shotDir, 'verdicts'), { recursive: true });
  fs.copyFileSync(path.resolve(file), path.join(shotDir, 'verdicts', `${id}.json`));
  l.stages[id] = {
    state: v.verdict === 'PASS' ? 'passed' : 'failed', owner: stage.owner, kind: stage.kind,
    at: new Date().toISOString(), gateVersion: GATE_VERSION,
    specHash: ctx.specHash, srcHash: ctx.srcHash,
    findings: v.findings || [], quote: v.summary || '', verdictFile: `verdicts/${id}.json`
  };
  if (v.verdict === 'REJECT') l.rejections.push({ stage: id, at: new Date().toISOString(), findings: v.findings || [] });
  writeLedger(l);
  console.log(`${v.verdict === 'PASS' ? C.g + 'PASSED' + C.x : C.r + 'REJECTED' + C.x}  ${id} signed by ${v.agent}`);
  process.exit(v.verdict === 'PASS' ? 0 : 1);
}

if (cmd === 'approve') {
  const [, , , , stage, quote] = process.argv;
  if (stage !== 'still') { console.error('only the still gate is approved this way'); process.exit(2); }
  const l = readLedger();
  const ctx = context();
  const before = openStages(l, ctx, stageIndex('still'));
  if (before.length) { console.error(`${C.r}refused${C.x} — the still cannot be approved while ${before.map(s => s.id).join(', ')} are open`); process.exit(1); }
  if (!quote || quote.length < 3) { console.error('an approval needs the user\'s words, quoted'); process.exit(2); }
  l.approvals.still = { quote, at: new Date().toISOString() };
  l.stages.still = { state: 'approved', owner: 'user', kind: 'user', at: new Date().toISOString(), quote };
  writeLedger(l);
  console.log(`${C.g}APPROVED${C.x} still · "${quote}"`);
  process.exit(0);
}

if (cmd === 'override') {
  const [, , , , stage, reason] = process.argv;
  if (!byId(stage)) { console.error(`no stage ${stage}`); process.exit(2); }
  if (!reason || reason.length < 8) { console.error('an override needs a reason that will be read in the ledger'); process.exit(2); }
  const l = readLedger();
  l.overrides = l.overrides || {};
  l.overrides[stage] = { reason, by: 'director', at: new Date().toISOString() };
  writeLedger(l);
  console.log(`${C.y}override recorded${C.x} ${stage} — "${reason}"`);
  console.log(`${C.d}an override is not an approval; it is on the record and it keeps the shot unlocked${C.x}`);
  process.exit(0);
}

if (cmd === 'reject') {
  const [, , , , stage, why] = process.argv;
  if (!byId(stage)) { console.error(`no stage ${stage}`); process.exit(2); }
  if (!why) { console.error('a rejection must name the gate that should have caught it, in one sentence'); process.exit(2); }
  const l = readLedger();
  l.rejections.push({ stage, at: new Date().toISOString(), by: 'user', why });
  for (const s of STAGES.slice(stageIndex(stage))) delete l.stages[s.id];
  writeLedger(l);
  console.log(`${C.y}sent back${C.x} to ${stage} — ${why}`);
  console.log(`${C.d}the pipeline will not advance past ${stage} until it passes again${C.x}`);
  process.exit(0);
}

console.error(`unknown command ${cmd}`);
process.exit(2);
