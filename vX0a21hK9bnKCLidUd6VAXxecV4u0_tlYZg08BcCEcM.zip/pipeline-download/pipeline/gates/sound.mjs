/* pipeline/gates/sound.mjs — the mix, measured.

   Three questions, all of them mechanical:
     · is the track at a sane level for a phone (mean −24…−12 dB, peak under −1 dBFS)
     · does a line start in a silence (the voice is not where the spec says it is)
     · does the piece end in a silent tail (it reads as having ended early)

   silencedetect is good to about ±0.1 s, so a line starting 0.02 s before a silence ends is
   measurement precision, not a misplaced line. The report prints both, so a person can see which. */

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import ffmpegPath from 'ffmpeg-static';
import { ROOT_DIR, F, verdict } from './lib.mjs';

export async function runSoundGate(spec) {
  const findings = [];
  const track = spec.sound?.track && path.join(ROOT_DIR, spec.sound.track);
  if (!track || !fs.existsSync(track))
    return { ok: false, findings: [F('8-sound', 'no mixed track declared or found', 'add "sound": {"track": ...} and mix it')], report: '' };

  const vol = spawnSync(ffmpegPath, ['-i', track, '-af', 'volumedetect', '-f', 'null', '-'], { encoding: 'utf8' });
  const mean = +(vol.stderr.match(/mean_volume: (-?[\d.]+)/) || [])[1];
  const max = +(vol.stderr.match(/max_volume: (-?[\d.]+)/) || [])[1];
  if (!(mean >= -24 && mean <= -12)) findings.push(F('8-sound', `mean level ${mean} dB is outside −24…−12`, 'normalise to about −16 LUFS'));
  if (!(max <= -1.0)) findings.push(F('8-sound', `peak ${max} dB is over −1 dBFS`, 'lower the limiter'));

  const sil = spawnSync(ffmpegPath, ['-i', track, '-af', 'silencedetect=noise=-45dB:d=0.3', '-f', 'null', '-'], { encoding: 'utf8' });
  const opens = [...sil.stderr.matchAll(/silence_start: ([\d.]+)/g)].map(m => +m[1]);
  const closes = [...sil.stderr.matchAll(/silence_end: ([\d.]+)/g)].map(m => +m[1]);
  const total = spec.duration || null;

  if (total && opens.length && closes.length) {
    const lastOpen = opens[opens.length - 1], lastClose = closes[closes.length - 1];
    if (lastOpen > lastClose && lastOpen < total - 1.0)
      findings.push(F('8-sound', `silent tail from ${lastOpen.toFixed(2)}s to the end`, 'end the piece with the voice, not after it'));
  }
  for (const l of spec.lines || []) {
    const hit = opens.findIndex((o, i) => l.in > o && ((closes[i] ?? o + 10) - l.in) > 0.15);
    if (hit >= 0)
      findings.push(F('8-sound', `line ${l.v} starts at ${l.in}s, ${((closes[hit] ?? 0) - l.in).toFixed(2)}s before the speech does`, 're-place the line on its word'));
  }

  const report = `mean ${mean} dB · peak ${max} dB\nsilences: ${opens.map((o, i) => `${o.toFixed(2)}–${(closes[i] ?? 0).toFixed(2)}`).join(', ') || 'none'}`;
  return verdict('sound', findings, report);
}
