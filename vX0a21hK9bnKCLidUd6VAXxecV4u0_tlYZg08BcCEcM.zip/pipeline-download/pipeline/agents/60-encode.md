# agent · encode

**Owns:** the file.
**Delivers:** `silent.mp4` → muxed `<shot>.mp4` at the spec's frame size, and a sheet every 2 s.

**Refuses to run** until the user has approved a still. This is not a convention; `run.mjs` checks it.
**Checks after encoding:** the encoded dimensions against the spec, the levels, and that the sheet shows
what the build showed.
