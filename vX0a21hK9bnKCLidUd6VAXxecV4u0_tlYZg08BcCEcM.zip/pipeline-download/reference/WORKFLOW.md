# THE WORKFLOW

This document is the operating system for the whole slate, not a set of notes about one cut.
It says what a shot is, what it has to prove before it exists, who is allowed to approve it, and
what happens when it is rejected. Tools change; this does not.

It replaces `ep01/WORKFLOW.md`, which described the pilot and was written as we learned. Keep that
file for the history — the four rules it ends on (R1–R4) are now gate items, not advice.

---

## 1. The unit of work

Three sizes, and they nest. Never work at the wrong size.

| size | what it is | how long | who signs it off |
|---|---|---|---|
| **slate** | the ten episodes and their order | the whole project | the user, once |
| **episode** | one argument, one narration track, one assembly | 6–10 shots | the user, at three checkpoints |
| **shot** | one continuous screen, 8–30 s, one spec file | one build | the user, on **one still**, then on the encoded file |

A shot is the only thing that gets built. An episode is assembled from approved shots and is never
"designed" at assembly time. If assembly needs something that wasn't approved as a shot, that is a
new shot and it starts at gate 0.

## 2. States, and who may move them

Every artifact carries exactly one state. No artifact skips a state, and no state is implied.

    draft → reified → designed → gated → still_approved → built → watched → locked

| state | means | may be set by |
|---|---|---|
| `draft` | the line exists, nothing drawn | anyone |
| `reified` | the line has been written down as an object in the world (§5, gate 1) | the writer |
| `designed` | composition fixed: where things sit, what the type does, what the accent points at | the designer |
| `gated` | every mechanical gate returns zero findings **and** the semantic gate is signed in writing | the pipeline + a written pass |
| `still_approved` | the user has seen one still at delivery size and approved it, in their words, recorded | **the user only** |
| `built` | encoded, muxed, levels measured | the pipeline |
| `watched` | the encoded file has been watched end to end **and** the shot is signed | **the user only** |
| `locked` | part of the episode | the user, implicitly, by not reopening it |

Two hard consequences:

- **Nothing is encoded before `still_approved`.** Encoding is the most expensive step we have and
  the least informative. A still at delivery size costs seconds and catches almost everything.
- **`gated` is not `approved`.** A green report is evidence that a list of defects is absent. It is
  not evidence that the thing is good. That distinction has been the single most expensive lesson
  on this project; it is now the first line of §7.

## 3. The three checkpoints per episode

Between them the episode is ours. At them, it is the user's.

| # | checkpoint | what the user receives | what their word unlocks |
|---|---|---|---|
| **C1** | the argument | script + VO, measured to the second | building shots |
| **C2** | the look | one still per shot, at delivery size, on one sheet | encoding any shot |
| **C3** | the film | the assembled master, watched by us first | packaging (title, thumbnail, description) |

A checkpoint is not a question ("is this okay?"). It is a decision with two outcomes, and both are
recorded. A checkpoint may not be split into five small approvals; if the user wants to see a shot
early, that shot goes to C2 on its own.

## 4. The shot spec

Every shot is one JSON file at `ep01/shots/<id>/<id>.spec.json`. The spec is the contract between
the drawing and the gates: it is what lets a tool know what it is looking at without being told each
time. If a fact is not in the spec, no gate can check it, and the shot is not ready to be built.

```jsonc
{
  "shot": "ep01/s04-rack-100-homes",
  "episode": 1, "beat": 2,
  "format": "vertical",                       // "vertical" | "landscape"
  "frame": {
    "w": 1080, "h": 1920,
    "margin": { "l": 72, "r": 72, "t": 56 },
    "safe_b": 1690                            // nothing at all below this line
  },
  "palette": "DESIGN.md#sheet-vertical",       // one palette per shot, named, not inline

  // ---- the audio frame: measured, not estimated ----
  "lines": [
    { "v": "l1", "file": "audio/v1.mp3", "text": "One rack. A hundred homes.",
      "trim": [0.29, 2.78], "in": 0.22 }
  ],

  // ---- what is on screen, and what each thing is for ----
  "objects": [
    { "name": "cabinet", "projection": "elevation", "count": 1,
      "serves": ["l2", "l5"], "reads_without_caption": "a rack of servers" },
    { "name": "house", "projection": "elevation", "count": 100,
      "serves": ["l3", "l4"], "reads_without_caption": "a house" }
  ],
  "whitelist": ["cabinet", "unit", "patch", "house", "windowlight", "dimension"],

  // ---- the count, if the shot makes a number mean something ----
  "count": { "object": "house", "from": 6.45, "to": 10.00, "target": 100, "max_jump": 4 },

  // ---- every change, with the reason it exists ----
  "beats": [
    { "t": 0.20, "what": "the cabinet starts to fill", "why": "l1 introduces the object" },
    { "t": 4.85, "what": "120 kW lands beside the rack", "why": "the word 'kilowatts' at 5.6" }
  ],

  "camera": { "moves": [], "note": "one projection; the camera does not move" },

  "gates": {
    "mechanical": { "safe": "v", "max_texts": 3, "chrome": ["UNSEXY SYSTEMS"] },
    "semantic":   { "invented": 0, "abstract_standins": 0, "projections_per_object": 1 },
    "rhythm":     { "change_every": [2, 4], "transform_every": [5, 8], "holds_max": 1.2 },
    "motion":     { "cuts": [], "zoom": [] }
  },

  "waivers": [],                               // each: what, why, and it prints in the report

  "approval": {
    "still": "ep01/build/v-16p4.png",
    "approved_by": null, "quote": null, "date": null, "state": "gated"
  }
}
```

Rules the spec enforces by its own shape:

- **Every object names a line it serves.** An object with no line is invented content (R1).
- **Every object names its projection.** Two projections on one object is the defect that made parts
  look pasted on; one field, one answer.
- **Every beat carries a reason.** A change without a reason is the animation the narration did not
  ask for.
- **A count names its object, its window and its target**, so "a hundred" can be checked as a count
  rather than admired as a texture.
- **Waivers are declared, never silent.** A waiver prints in the report with its reason.

## 5. The engine contract

One shared page engine draws every shot. A shot is a spec plus small drawing code; the engine owns
the frame, the palette, the type, the audit surface and the clock. Every shot exposes exactly these,
and the gates use nothing else:

| export | returns | used by |
|---|---|---|
| `__draw(t)` | sets the frame at time `t`, synchronously, no async assets | every gate, the renderer |
| `__total()` | seconds | every gate |
| `__audit(t)` | `{ objects:[{name,parent,serves,box}], texts, textBoxes, whitelist }` | scene gate |
| `__boxesAt(t)` | text boxes only | type gate |
| `__cam(t)` | `{ view, z, xc }` | motion gate |
| `__ready` | `true` once fonts are loaded and the first draw is done | everything |

`data-name`, `data-parent`, `data-serves` on every drawn element is the whole audit surface. An
element without them is invisible to the gates — which means it is invisible to the process and does
not belong in a shot.

## 6. The gate ladder

In order. A shot may not skip a gate, and a later gate may not be used to excuse an earlier one.

| gate | question | kind | fails on |
|---|---|---|---|
| **0 · spec legal** | is the spec complete and self-consistent? | automatic | missing serves, missing projection, count with no target, beat with no reason |
| **1 · reification** | is the line written down as an object in the world? | written | a symbol standing in for a thing; "power" instead of a conductor |
| **2 · design** | is the composition fixed before code? | written | text placed by eye against an object; accent doing two jobs |
| **3 · type & frame** | does any text break the frame, collide, or crowd? | automatic | outside margins, overlapping text, >3 fragments, text in the lower 12 % |
| **4 · scene** | is every object allowed, serving, contained, countable? | automatic | unwhitelisted object, uncontained overlap, count that jumps or reverses |
| **5 · semantics** | does the picture say what the sentence says? | written | invented content, abstract stand-in, object unreadable without its caption |
| **6 · rhythm** | does the state change often enough, and does it mean something? | automatic + written | a still stretch over 2 s; a change that is only motion, not information |
| **7 · motion** | is the move clean? | automatic | undeclared camera, cropped subject, pop, mechanical motion |
| **8 · sync** | does each thing arrive on the word that names it? | automatic + watched | the number before the sentence, the count after the claim |
| **9 · encode** | does the file survive encoding? | automatic + watched | crop at encoded size, levels, dead tail, silent tail |
| **10 · user** | is it good? | **the user** | anything, and their reason becomes a gate amendment |

Gates 3, 4, 7 are the ones that exist as tools today (`qa.mjs`, `scene.mjs`, `motion.mjs`). Gates 1,
2, 5, 6 are written passes with a fixed shape: line by line, *what the audio says → what the frame
shows → does the frame say it*. Gate 0 is a schema check on the spec, and it is deliberately
pedantic, because every failure after it is more expensive.

### Gate 6, stated precisely

Because "the rhythm feels wrong" is not checkable and "nothing moved for 1.3 s" is:

- no still stretch longer than **2.0 s** anywhere;
- at least one **change of state** every 2–4 s — something appears, leaves, is counted, is
  reframed, is compared, or is emphasised;
- at least one **transformation** every 5–8 s — a bigger change in what the viewer is looking at,
  not a bigger change in how much moves;
- the last frame is a **held card**, not an accident: the piece ends on a state we chose;
- no change that only moves pixels. If a change can't be said in the `why` field, it doesn't happen.

## 7. Rejection routing — the part that was missing

A rejection is not a restart. A rejection names **the gate that should have caught it**, and the
shot returns to that gate only.

    user rejects
      → name the gate that should have caught it      (written, in one sentence)
      → fix at that gate, re-run from that gate down
      → write one amendment into that gate's checklist
      → the amendment is permanent and applies to every later shot

Examples from this project, already folded in:

| rejection | gate that should have caught it | amendment it produced |
|---|---|---|
| "he should check are there any errors in the margins" | 3 · type & frame | margins are checked at delivery size, in the shot's own format |
| "nothing invented" | 0 · spec legal | every object names the line it serves, or it fails the spec |
| "an object must read as its object without the caption" | 5 · semantics | `reads_without_caption` is a required field, answered in words |
| "a count must be counted, not tiled" | 4 · scene | counts are checked monotone, one at a time, with a max jump |
| "it cropped the image when it zoomed" | 7 · motion | any clip of the drawing is a defect, including in the vertical cut |
| "the frame sat dead for 12 s" | 6 · rhythm | holds over 2 s fail, and the change per second is printed |
| "the critic passed it and it was still bad" | 10 · user | a green report is never an approval; only a person approves |

The checklist for each gate lives at the bottom of this file and only ever grows.

## 8. Sign-off

Approval is a recorded fact with a witness, not a mood. `approval` in the spec is filled by the user's
own words, quoted, with the date and the still they approved:

```json
"approval": {
  "still": "ep01/build/v-16p4.png",
  "approved_by": "user",
  "quote": "that's almost near to perfect",
  "date": "2026-10-27",
  "state": "still_approved"
}
```

The still that was approved is kept. If the still changes, the approval is void — this is the rule
that stops a "small fix" quietly becoming a different shot.

## 9. Change control after approval

| change | what reopens |
|---|---|
| a colour, a margin, a type size | nothing below gate 3 — re-run 3→10 |
| a new object, or an object leaves | 0 (spec) → 10 |
| a timing change | 6 → 10 |
| the narration | 1 → 10, the whole shot |
| anything the user can see | their gate, again |

Nothing is ever changed "while we're in there". Every change names a gate before it is made.

## 10. Episode checkpoints, applied to the slate

| # | episode | argument | state |
|---|---|---|---|
| 1 | Texas isolation | *(pilot)* | shots in progress; 1 and 2 the rack/100 homes exist as landscape + vertical |
| 2 | capacity auction `$333.44` | | unstarted |
| 3 | interconnection queue | | unstarted |
| 4 | the transformer | | unstarted |
| 5 | Google pays 57 % above market | | unstarted |
| 6 | sixty hertz | | unstarted |
| 7 | the substation box | | unstarted |
| 8 | negative prices | | unstarted |
| 9 | the blackout that started with one line | | unstarted |
| 10 | one building, one city | | unstarted |

Wave 60 % / evergreen 30 % / anchor 10 %. Slate-level decisions already made and not revisited per
episode: engineering & infrastructure for the systems professional, tier-1 audience, monetisable,
producible as motion graphics.

## 11. What the machine may decide, and what it may not

**The machine may:** fail a shot, count objects, measure dead holds, measure levels, check the frame
against the spec, reproduce a still in seconds, and report what changed between two versions.

**The machine may not:** approve anything, decide that a symbol is fine "because it reads", decide
that a frame is legible from a score, or decide that a green report means the shot is good.

**The user may not be asked:** questions the spec already answers. If a decision is in the spec, the
pipeline makes it and reports it.

## 12. Standing rules that live in the pipeline

These are not advice; each one is a field or a check:

- fragments only, 2–3 words, never more than three on screen (gate 3)
- nothing in the lower 12 %, nothing under the player (gate 3)
- same margin and padding in every frame of a shot (gate 3)
- one accent per moment, and it points at something (gate 2)
- one projection per object (spec → gate 0)
- no invented content, no abstract stand-in (gate 5)
- a count is counted, one object at a time (gate 4)
- no camera move without a declared reason; cropping the subject is a defect (gate 7)
- no mechanical motion, no animation the narration did not ask for (gate 6)
- cut only when the narration changes the place (gate 6)
- no subtitles (gate 3)
- title and thumbnail share one promise (C3)
- copy means inspiration, not reuse
- never promise zero errors; promise a process that catches them first

## 13. Definition of done

A shot is done when all of these are true at once, and none of them is inferred:

1. the spec is complete and legal, and no field says `null` except `approval` before the user speaks;
2. gates 3, 4, 6, 7 return zero findings, and their reports are committed next to the spec;
3. gates 1, 2, 5 are signed in writing, line by line;
4. one still at delivery size is approved, quoted, dated, and saved;
5. the encoded file has been watched end to end by us, then by the user;
6. the manifest records which voice lines, which fonts, which palette and which render settings made
   the file, so it can be rebuilt exactly.

An episode is done when every shot is locked, the assembly has been watched, and the packaging asks
the same question the film answers.

---

## Appendix A — the growing checklist

Each line is a rejection that became a rule. Add; never remove.

**0 · spec legal** — every object names a line; one projection per object; count has a target; every
beat has a why; waivers declared.

**3 · type & frame** — margins at delivery size in the shot's own aspect; no text collisions; ≤3
fragments; nothing in the lower 12 %; the brand mark is chrome and is declared as such.

**4 · scene** — whitelist; containment is allowed, overlap is not; counts monotone with a max jump;
every object's box inside the frame.

**5 · semantics** — objects readable without their caption; no invented marks; the two things a
sentence compares are drawn the same way at the same scale; if the sentence says a number, the frame
makes the number mean something visible.

**6 · rhythm** — no hold >2 s; a state change every 2–4 s; a transformation every 5–8 s; the closing
frame is chosen; the change-per-second figure is printed so the pass can be audited.

**7 · motion** — no undeclared camera; no clip of the subject; no pop; no mechanical motion; nothing
leaves the frame or sits under the controls.

**8 · sync** — a number arrives within 0.4 s of the word that names it; a comparison is on screen
when the comparison is spoken; nothing is said that is not on screen.

**9 · encode** — crop checked at encoded size; loudness ≈ −16 LUFS with peak ≤ −1.5 dB; no silent
tail, no dead tail; the sheet is watched, not just generated.
