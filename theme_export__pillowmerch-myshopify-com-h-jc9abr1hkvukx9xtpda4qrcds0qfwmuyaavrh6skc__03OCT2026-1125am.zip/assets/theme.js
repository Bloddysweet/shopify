/* =========================================================
   PillowTalk theme JS — no dependencies
   ========================================================= */
(function () {
  'use strict';

  var moneyFormat = (window.theme && window.theme.moneyFormat) || '${{amount}}';

  function money(cents) {
    var amount = (cents / 100).toFixed(2);
    return moneyFormat.replace(/\{\{\s*(\w+)\s*\}\}/g, function (m, key) {
      return key === 'amount' ? amount : '';
    });
  }

  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function lockScroll(on) { document.body.classList.toggle('pt-locked', !!on); }

  var toastTimer;
  function toast(message) {
    var el = qs('#PtToast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('is-visible'); }, 2600);
  }
  window.ptToast = toast;

  /* ---------------- mobile nav ---------------- */
  function initNav() {
    var nav = qs('#PtMobileNav');
    var openBtn = qs('[data-mnav-open]');
    if (!nav || !openBtn) return;

    function open() {
      nav.classList.add('is-open');
      nav.setAttribute('aria-hidden', 'false');
      lockScroll(true);
    }
    function close() {
      nav.classList.remove('is-open');
      nav.setAttribute('aria-hidden', 'true');
      lockScroll(false);
    }

    openBtn.addEventListener('click', open);
    qsa('[data-mnav-close]', nav).forEach(function (b) { b.addEventListener('click', close); });
    nav.addEventListener('click', function (e) { if (e.target === nav) close(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  }

  /* ---------------- cart drawer ---------------- */
  var drawer;

  function openDrawer() {
    if (!drawer) return;
    drawer.classList.add('is-open');
    drawer.setAttribute('aria-hidden', 'false');
    lockScroll(true);
    var btn = qs('.drawer__panel .icon-btn', drawer);
    if (btn) btn.focus();
  }

  function closeDrawer() {
    if (!drawer) return;
    drawer.classList.remove('is-open');
    drawer.setAttribute('aria-hidden', 'true');
    lockScroll(false);
  }

  function refreshCartCount() {
    fetch('/cart.js', { headers: { 'Content-Type': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (cart) {
        qsa('[data-cart-count]').forEach(function (el) {
          el.textContent = cart.item_count;
          if (cart.item_count > 0) el.removeAttribute('hidden');
          else el.setAttribute('hidden', '');
        });
      })
      .catch(function () {});
  }

  function refreshDrawer() {
    if (!drawer) return;
    fetch('/?sections=cart-drawer', { headers: { 'Content-Type': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data && data['cart-drawer']) {
          var body = qs('.drawer__body', drawer);
          var foot = qs('.drawer__foot', drawer);
          var tmp = document.createElement('div');
          tmp.innerHTML = data['cart-drawer'];
          var nb = qs('.drawer__body', tmp);
          var nf = qs('.drawer__foot', tmp);
          if (body && nb) body.innerHTML = nb.innerHTML;
          if (foot && nf) foot.innerHTML = nf.innerHTML;
        }
        refreshCartCount();
      })
      .catch(function () {});
  }

  function addToCart(items, opts) {
    opts = opts || {};
    return fetch('/cart/add.js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ items: items })
    })
      .then(function (r) {
        if (!r.ok) throw new Error('add failed');
        return r.json();
      })
      .then(function () {
        refreshCartCount();
        refreshDrawer();
        if (!opts.silent) {
          toast('Added to bag 🎉');
          openDrawer();
        }
      })
      .catch(function () {
        toast('Hmm, that didn’t work. Try again?');
      });
  }

  function initDrawer() {
    drawer = qs('#PtDrawer');
    if (!drawer) return;

    qsa('[data-drawer-open]').forEach(function (b) {
      b.addEventListener('click', function (e) { e.preventDefault(); openDrawer(); });
    });
    qsa('[data-drawer-close]', drawer).forEach(function (b) {
      b.addEventListener('click', function (e) { e.preventDefault(); closeDrawer(); });
    });
    drawer.addEventListener('click', function (e) {
      if (e.target === qs('.drawer__overlay', drawer)) closeDrawer();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && drawer.classList.contains('is-open')) closeDrawer();
    });

    /* delegated controls inside the drawer */
    drawer.addEventListener('click', function (e) {
      var qtyBtn = e.target.closest('[data-line-qty]');
      if (qtyBtn) {
        var line = parseInt(qtyBtn.getAttribute('data-line'), 10);
        var delta = parseInt(qtyBtn.getAttribute('data-line-qty'), 10);
        var input = qs('[data-line-input="' + line + '"]', drawer);
        var next = Math.max(0, parseInt(input.value, 10) + delta);
        updateLine(line, next, qtyBtn);
        return;
      }
      var rm = e.target.closest('[data-line-remove]');
      if (rm) {
        e.preventDefault();
        updateLine(parseInt(rm.getAttribute('data-line-remove'), 10), 0, rm);
      }
    });

    drawer.addEventListener('change', function (e) {
      var input = e.target.closest('[data-line-input]');
      if (input) {
        var v = Math.max(1, parseInt(input.value, 10) || 1);
        updateLine(parseInt(input.getAttribute('data-line-input'), 10), v, input);
      }
    });

    function updateLine(line, qty, trigger) {
      if (trigger) trigger.setAttribute('disabled', 'disabled');
      fetch('/cart/change.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ line: line, quantity: qty })
      })
        .then(function (r) { return r.json(); })
        .then(function () { refreshDrawer(); })
        .catch(function () { toast('Could not update your bag.'); })
        .then(function () { if (trigger) trigger.removeAttribute('disabled'); });
    }
  }

  /* ---------------- product form ---------------- */
  function initProductForm() {
    var form = qs('[data-product-form]');
    if (!form) return;

    var jsonEl = qs('[data-product-json]');
    var variants = [];
    try { variants = JSON.parse(jsonEl.textContent); } catch (e) { variants = []; }

    var priceEl = qs('[data-product-price]');
    var addBtn = qs('[data-add-btn]', form);
    var idInput = qs('[name="id"]', form);
    var statusEl = qs('[data-product-status]', form);

    function currentVariant() {
      var opts = qsa('[data-option-input]:checked', form).map(function (i) { return i.value; });
      return variants.filter(function (v) {
        return v.options.every(function (o, idx) { return o === opts[idx]; });
      })[0];
    }

    function sync() {
      var v = currentVariant();
      if (!v) return;
      if (idInput) idInput.value = v.id;
      if (priceEl) priceEl.innerHTML = '<span class="price' + (v.compare_at_price > v.price ? ' price--sale' : '') + '">' +
        money(v.price) +
        (v.compare_at_price > v.price ? ' <s>' + money(v.compare_at_price) + '</s>' : '') +
        '</span>';
      if (addBtn) {
        addBtn.disabled = !v.available;
        var label = qs('[data-add-label]', addBtn);
        if (label) label.textContent = v.available ? 'Add to bag' : 'Sold out';
      }
      if (statusEl) statusEl.textContent = v.available ? '' : 'That combo is sold out. Try another size.';
      if (history.replaceState && v.id) {
        history.replaceState(null, '', '?variant=' + v.id);
      }
    }

    form.addEventListener('change', function (e) {
      if (e.target.matches('[data-option-input]')) sync();
    });

    form.addEventListener('submit', function (e) {
      if (form.dataset.ajax !== 'true') return;
      e.preventDefault();
      var v = currentVariant();
      if (!v) return;
      addToCart([{ id: v.id, quantity: parseInt(qs('[name="quantity"]', form).value, 10) || 1 }]);
    });

    sync();
  }

  /* quantity steppers (product page) */
  function initQuantity() {
    qsa('[data-qty]').forEach(function (wrap) {
      var input = qs('input', wrap);
      if (!input) return;
      qsa('button', wrap).forEach(function (b) {
        b.addEventListener('click', function () {
          var delta = parseInt(b.getAttribute('data-qty'), 10);
          var next = Math.max(1, (parseInt(input.value, 10) || 1) + delta);
          input.value = next;
          input.dispatchEvent(new Event('change', { bubbles: true }));
        });
      });
    });
  }

  /* ---------------- gallery ---------------- */
  function initGallery() {
    var main = qs('[data-gallery-main]');
    if (!main) return;
    var img = qs('img', main);
    qsa('[data-gallery-thumb]').forEach(function (t) {
      t.addEventListener('click', function () {
        qsa('[data-gallery-thumb]').forEach(function (x) { x.classList.remove('is-active'); });
        t.classList.add('is-active');
        var src = t.getAttribute('data-src');
        if (img && src) img.setAttribute('src', src);
      });
      t.addEventListener('mouseenter', function () {
        var src = t.getAttribute('data-src');
        if (img && src) img.setAttribute('src', src);
      });
    });
  }

  /* ---------------- quick add ---------------- */
  function initQuickAdd() {
    qsa('[data-quick-add]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var id = btn.getAttribute('data-quick-add');
        btn.setAttribute('disabled', 'disabled');
        addToCart([{ id: id, quantity: 1 }]).then(function () {
          btn.removeAttribute('disabled');
        });
      });
    });
  }

  /* ---------------- reveal on scroll ---------------- */
    function initReveal() {
      var items = qsa('.reveal:not(.is-in)');
    if (!items.length || !('IntersectionObserver' in window)) {
      items.forEach(function (i) { i.classList.add('is-in'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-in');
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    items.forEach(function (i) { io.observe(i); });
  }

  /* ---------------- collection sort ---------------- */
  function initSort() {
    var sel = qs('[data-sort-by]');
    if (!sel) return;
    sel.addEventListener('change', function () {
      window.location.href = sel.value;
    });
  }

  /* ---------------- sticky header shadow ---------------- */
  function initHeader() {
    var header = qs('.header');
    if (!header) return;
    var last = 0;
    window.addEventListener('scroll', function () {
      var y = window.scrollY;
      header.style.boxShadow = y > 8 ? '0 6px 0 rgba(22,17,15,.12)' : '';
      last = y;
    }, { passive: true });
  }

  function init() {
    initNav();
    initDrawer();
    initProductForm();
    initQuantity();
    initGallery();
    initQuickAdd();
    initReveal();
    initSort();
    initHeader();
    refreshCartCount();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  document.addEventListener('theme:cart:refresh', function () {
    refreshCartCount();
    refreshDrawer();
  });

  /* exposed so lazily-loaded sections can re-trigger animations */
  window.ptReveal = function () { initReveal(); };
})();
