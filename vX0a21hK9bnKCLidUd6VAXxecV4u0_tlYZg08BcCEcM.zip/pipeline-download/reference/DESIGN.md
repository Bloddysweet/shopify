# EP01 — DESIGN SYSTEM

The look has to be argued from the subject, not from taste. This film is about engineered systems
that nobody can photograph: a grid, a load, a queue, a market. So the frame is **a sheet from a
technical dossier** — the visual language of people who actually measure things.

Nothing decorative. Every mark on screen is either a measurement, a boundary, or a label.

---

## Ground and ink

| Role | Hex | Use |
|---|---|---|
| Ground | `#0A0B0D` | the whole frame, always |
| Ink | `#E9E5DC` | linework, primary type |
| Muted | `#7E7A72` | labels, annotations, the sheet furniture |
| Accent | `#FF5A1F` | **one thing per beat.** The number the narration is asserting. Never twice in a frame, never for decoration. |

The accent is the discipline of the whole system. If orange appears in two places, the frame has
two points and therefore none.

## Type

- **Space Grotesk 700** — the fragment. Uppercase, tracking −0.02em. This is the only thing that
  shouts.
- **Space Grotesk 400** — supporting sentences, never more than one line.
- **JetBrains Mono 500** — every number, every annotation, every unit. Numbers are instrument
  readings, so they get the instrument face.

Fragments are 2–3 words, uppercase, never a sentence. No subtitles anywhere in the film.

## Geometry

- Stage **1300 × 740**. Content box **x 60 → 1240, y 40 → 660**.
- Player controls occupy the bottom 68 px. Nothing is ever placed below **y 672**.
- All hairline rules are **1 px**. Construction lines sit at 12% ink; stated rules at 100%.
- Corner registration ticks, 10 px, at the four corners of the content box. Present in every
  frame, never explained.
- Sheet furniture, bottom-left, mono 10 px, muted: `EP01 · SHEET 0n/10`.
- Margins and padding are identical in every frame by construction — they are set once, in CSS
  variables, and no beat is allowed to override them.

## Motion

- Elements **draw on**, they never fly in. A line extends; a box grows from its baseline.
- No element exits the frame, ever. Once placed, a thing stays until the beat ends.
- The screen continues — it does not cut back and forth. A state change happens only when the
  narration changes subject.
- Numbers arrive and stay. A number is never re-animated, counted up, or bounced.

## What this system refuses

No gradients as a substitute for structure. No glow. No stock icons. No drop shadows. No
"cinematic" vignette. No particle effects. Nothing that means "we could not think of a real
mark."

---

## Beat 1 as built — the argument in a frame

The building is an **empty outline**. That is the entire claim of the first beat: nothing is made
inside it. When the narration says "it is not a factory", the label goes *inside* the empty box,
because the emptiness is the sentence.

Elements, in the order the narration names them:

1. `RICHLAND PARISH` — top left, mono, muted.
2. The rectangle rises from the baseline over the first sentence. Nothing else moves.
3. `5 GIGAWATTS` — arrives in accent when the number is spoken, with a leader line back to the
   box it describes.
4. `NOT A FACTORY` — inside the box, when the narration says it.

Four states across 38 seconds. That is deliberate: this beat is one shot, and it holds.
