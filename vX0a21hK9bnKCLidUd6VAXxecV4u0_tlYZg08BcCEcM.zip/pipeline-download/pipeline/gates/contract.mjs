/* pipeline/gates/contract.mjs — the page contract.

   Every gate measures a page by calling into it. If a page does not expose those hooks, the gates
   do not fail with a finding, they crash inside puppeteer with a message about an undefined
   function — which tells you nothing about your drawing. So the contract is checked first, by
   itself, with names in the findings.

   A page must expose, on `window`:
     __ready            true once fonts are loaded and the first frame can be drawn
     __total()          the length of the shot in seconds (the spec's duration must agree)
     __draw(t)          put the page in its state at time t — deterministic, stateless
     __boxesAt(t)       every text box visible at t: [{s, x0, y0, x1, y1}] in page pixels
     __audit(t)         {objects:[{name,parent,serves,x0,y0,x1,y1}], texts:[], textBoxes:[], whitelist:[]}
     __cam(t)           optional: {view, z, xc} for shots that declare a camera move

   __draw is the important one. The page is not an animation that plays; it is a function of time.
   A page that keeps its own state cannot be sampled at 0.1 s and cannot be rendered frame by
   frame, and both of those are how this pipeline sees.

   See pipeline/PAGE.md for the template.                                                          */

import path from 'node:path';
import fs from 'node:fs';
import puppeteer from 'puppeteer';
import { ROOT_DIR, F } from './lib.mjs';

const HOOKS = ['__total', '__draw', '__boxesAt', '__audit'];

export async function runContractGate(spec) {
  const findings = [];
  const notes = [];

  const file = path.join(ROOT_DIR, spec.src || '');
  if (!spec.src) return { ok: false, findings: [F('2-image', 'the spec names no drawing', 'add "src"')], report: '' };
  if (!fs.existsSync(file)) return { ok: false, findings: [F('2-image', `nothing at ${spec.src}`, 'the image agent has not delivered')], report: '' };

  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage', '--font-render-hinting=none'] });
  try {
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', e => errors.push(String(e.message || e)));
    page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });

    await page.setViewport({ width: spec.frame.w, height: spec.frame.h, deviceScaleFactor: 1 });
    await page.goto('file://' + file, { waitUntil: 'load', timeout: 30000 });

    /* __ready, with a real timeout rather than a puppeteer stack trace */
    let ready = false;
    try { await page.waitForFunction('window.__ready===true', { timeout: 15000 }); ready = true; }
    catch { findings.push(F('2-image', 'the page never sets window.__ready = true',
      'set it after the fonts have loaded, or the gates are measuring an unstyled frame')); }
    if (errors.length) findings.push(F('2-image', `the page threw: ${errors[0].slice(0, 160)}`, 'fix the error before any measurement means anything'));

    /* every local file the page points at has to exist, and be named when it does not.
       "Failed to load resource: net::ERR_FILE_NOT_FOUND" costs an hour; the path costs a second. */
    const html = fs.readFileSync(file, 'utf8');
    const refs = new Set();
    for (const m of html.matchAll(/url\(\s*['"]?([^'")]+)['"]?\s*\)/g)) refs.add(m[1]);
    for (const m of html.matchAll(/(?:src|href)\s*=\s*['"]([^'"]+)['"]/g)) refs.add(m[1]);
    for (const ref of refs) {
      if (/^(data:|https?:|#|mailto:)/i.test(ref)) continue;
      const target = path.resolve(path.dirname(file), ref.split(/[?#]/)[0]);
      if (!fs.existsSync(target))
        findings.push(F('2-image', `the page points at a file that is not there: ${ref}`,
          `expected ${path.relative(ROOT_DIR, target)} — ship the font/asset, or inline it`, { ref }));
    }

    /* a font-face that failed to load falls back silently to a system font, and every margin
       measurement after that is of the wrong typeface */
    if (ready) {
      const bad = await page.evaluate(() => [...document.fonts].filter(f => f.status === 'error').map(f => `${f.family} ${f.weight}`));
      for (const b of bad)
        findings.push(F('2-image', `a font did not load: ${b}`, 'the page is being measured in a fallback face — ship the file'));
    }

    if (ready) {
      const missing = await page.evaluate(hooks => hooks.filter(h => typeof window[h] !== 'function'), HOOKS);
      for (const h of missing)
        findings.push(F('2-image', `the page does not expose window.${h}`, `every gate calls it — see pipeline/PAGE.md, the contract is six hooks`));

      /* the shape of what the hooks return, not just that they exist */
      if (!missing.length) {
        const total = await page.evaluate(() => window.__total());
        if (typeof total !== 'number' || !(total > 0))
          findings.push(F('2-image', `__total() returned ${JSON.stringify(total)}`, 'it must return the length of the shot in seconds'));
        else if (spec.duration && Math.abs(total - spec.duration) > 0.05)
          findings.push(F('2-image', `the page runs ${total}s and the spec says ${spec.duration}s`,
            'one of them is wrong — the mix, the render and the count all follow the spec'));

        const shape = await page.evaluate(t => {
          const b = window.__boxesAt(t), a = window.__audit(t);
          return {
            boxes: Array.isArray(b) ? b.length : -1,
            boxKeys: Array.isArray(b) && b[0] ? Object.keys(b[0]).sort().join(',') : null,
            audit: a && typeof a === 'object' ? Object.keys(a).sort().join(',') : null,
            objects: a && Array.isArray(a.objects) ? a.objects.length : -1
          };
        }, Math.min(0.5, (total ?? 1) / 2));

        if (shape.boxes < 0) findings.push(F('2-image', '__boxesAt(t) did not return an array', 'return [] when no text is visible'));
        else if (shape.boxes > 0 && shape.boxKeys !== 's,x0,x1,y0,y1')
          findings.push(F('2-image', `__boxesAt(t) returns boxes shaped ${shape.boxKeys}`, 'each box needs s, x0, y0, x1, y1 in page pixels'));
        if (!shape.audit) findings.push(F('2-image', '__audit(t) did not return an object', 'return {objects, texts, textBoxes, whitelist}'));
        else if (!/objects/.test(shape.audit)) findings.push(F('2-image', `__audit(t) returns ${shape.audit}`, 'it must include objects, texts, textBoxes and whitelist'));
        notes.push(`total ${total}s · ${shape.boxes} text box(es) at the first sample · ${shape.objects} object(s)`);
      }

      /* a drawing that is the same at every sample is not a drawing, it is a picture.
         Only ask once the hooks exist — otherwise this probe throws instead of reporting. */
      if (missing.length) { /* already reported above */ }
      else {
      const moved = await page.evaluate(t => {
        const sig = x => JSON.stringify([window.__boxesAt(x), window.__audit(x).objects.map(o => [o.name, Math.round(o.x0), Math.round(o.y0)])]);
        const mid = window.__total() / 2;
        return { a: sig(0.1), b: sig(mid), c: sig(Math.max(0.2, window.__total() - 0.2)) };
      }, 0);
      if (moved.a === moved.b && moved.b === moved.c)
        findings.push(F('2-image', 'the page is identical at the start, the middle and the end',
          'the shot never changes state — the motion gate will call this a dead hold'));
      }
    }
  } finally {
    await browser.close();
  }

  return { ok: findings.length === 0, findings, report: notes.join('\n') || 'contract satisfied' };
}
