# EP01 — "One Building. One City's Worth of Power."

Research pack. Every number below is sourced, and every derived number shows its arithmetic.
Locked rule: the episode is never framed around the viewer's own electricity bill.

---

## The claim we are making

A single AI campus, of the size already under construction, draws on the same scale as a
whole American city — and it appears in about three years, where the city took a century.

We make that claim on **two separate measures**, and the episode says which is which.
Never blend them.

---

## TESTED FACTS

### The largest things actually running

| Site | Announced | Running now (Oct 2026) | Source |
|---|---|---|---|
| Project Rainier, New Carlisle IN (Amazon) | ~2.2 GW across ~30 buildings | ~1,037 MW | ctaio.dev/en/ai-infrastructure/largest-ai-data-centers |
| Colossus 2, Memphis TN (xAI) | ~2 GW | ~946 MW | same |
| Fairwater Atlanta (Microsoft) | not disclosed | ~636 MW | same |
| Prometheus, New Albany OH (Meta) | ~1 GW | ~471 MW | same |
| Stargate Abilene TX (Oracle/OpenAI) | ~1.2 GW, 8 buildings | ~421 MW | same |

**No site has passed 1 GW of live IT power yet.** That is the honest starting point and it
should be on screen, because the gap between "announced" and "running" is the story.

Source detail: https://ctaio.dev/en/ai-infrastructure/largest-ai-data-centers/

### The largest thing planned

- **Meta Hyperion, Richland Parish, Louisiana** — up to **5 GW**, more than **$50 billion**,
  **11 buildings**, ~4.1 sq mi of land.
  Sources: https://www.cnbc.com/2026/07/13/meta-louisiana-data-center-investment-reaches-50-billion-amid-ai-push.html
  and https://spectrum.ieee.org/5gw-data-center
- Hyperion's dedicated gas plants total ~**7.5 GW** — **more than 30% of Louisiana's entire
  existing grid**.
  Source: https://gcn.com/rural-louisiana-campus-priced-over-billion/20942/
- At 5 GW across 11 buildings, that is just under **500 MW per building**.
  Source: https://spectrum.ieee.org/5gw-data-center
- IEEE's own comparison: 5 GW is "enough to power roughly **4.2 million U.S. homes**."
  Same source.

### Why one building draws so much

- Conventional server rack: **5–15 kW**.
- AI training rack (NVIDIA GB200/Blackwell): **120–140 kW**, with next generation approaching
  **1 MW**.
  Sources: https://brightlio.com/largest-ai-data-centers-in-the-world/ and
  https://qz.com/ai-data-centers-gigawatt-power-grid-strain-051126
- Average rack density across the industry hit **27 kW in 2026**, up from 16 kW in 2025 and
  7 kW in 2021 — the largest jump in the survey's ten-year history.
  Source: AFCOM State of the Data Center Report, cited at https://gpusmith.com/articles/en/pdfs/how-to-build-an-ai-datacenter.pdf

### The growth rate

- The record for a single data centre's IT power has **doubled every 10 months since mid-2024**.
  Source: https://epoch.ai/data-insights/frontier-data-center-power

### The comparison city — Houston

| Houston figure | Value | Source |
|---|---|---|
| Annual electricity consumption, city | **28.6 billion kWh = 28.6 TWh** | https://finance.yahoo.com/news/25-cities-highest-electricity-consumption-104528985.html |
| CenterPoint Houston Electric peak-system demand | **~21 GW** (2026) | https://microgridmedia.com/centerpoint-adds-1-2-billion-to-grid-plan-as-houston-data-center-power-demand-surges/ |
| Houston metro peak demand, record | **24.2 GW** | https://www.houstonchronicle.com/business/energy/article/texas-power-grid-record-demand-solar-batteries-22422118.php |
| Average US home, annual use | **~10,500 kWh/yr ≈ 1.2 kW average load** | EIA |

### Texas grid, for the scale ladder

- ERCOT record peak: **85.5 GW** (summer 2023).
- ERCOT 2031 forecast: **218 GW** unadjusted; **145 GW** on its own adjusted basis.
  Source: https://www.houstonchronicle.com/business/energy/article/ercot-texas-power-grid-growth-data-20263609.php

---

## DERIVED NUMBERS — show the arithmetic on screen

### 1. One rack, one street
120 kW rack ÷ 1.2 kW average home = **100 homes**.
*(Rounded down deliberately. Say "a hundred houses," not "a small neighbourhood" — vague
qualifiers are how these videos lose this audience.)*

### 2. One building, one city — ANNUAL ENERGY
5 GW at a realistic 80% load factor:
5,000 MW × 8,760 h × 0.80 = **35.0 TWh/yr**
Houston consumes **28.6 TWh/yr**.
**35.0 > 28.6 → one building, in one year, draws more electricity than all of Houston.**
This is the headline claim, and it is true.

### 3. One building, one city — PEAK POWER
5 GW against CenterPoint's **21 GW** Houston peak = **24%**.
So at any instant, the campus is **a quarter of the Houston grid**, not more than it.
We state this clearly. It makes claim 2 credible rather than making us look like we rounded
toward the headline.

### 4. The punchline
At a doubling every 10 months, a 5 GW building in 2026 is a **20 GW building in 2028** —
the whole Houston grid, in one site, twice over, on the current curve. Flag it as a curve,
not a forecast, because it will not hold, and say so out loud.

---

## NAMED FAILURES — one per section, all real

| Section | Named failure | The number |
|---|---|---|
| Scale | ERCOT, 15 Feb 2021 | frequency fell to **59.302 Hz**; below threshold for **4 min 23 s**; ~**20,000 MW** of load shed |
| Getting connected | Transformer supply | large power transformer lead time **~144 weeks (4 years)**; prices **+80% in five years** |
| Who pays | PJM capacity market | **$9.3 billion**, **+174%** in capacity cost, attributed to data-centre demand for the 2025/26 delivery year |

Sources for the above: ctaio/datacentredigest transformer analyses
(https://datacentredigest.com/the-transformer-shortage-nobody-saw-coming-how-a-quiet-component-crisis-is-throttling-data-center-power-delivery/),
and https://politifact.com/factchecks/2026/jun/12/elizabeth-warren/data-centers-rising-electricity-costs/

---

## THE COUNTER-ARGUMENT — we must include it

Data centres have historically *lowered* retail electricity prices. FERC/EIA data 2015–2024:
for every doubling of data-centre capacity, average retail prices fell **3.5%** — about **6%**
at state level.
Source: https://fortune.com/2026/07/26/data-centers-electricity-costs-cheaper-7billion-buildout-ai-demand/

This audience will know this. Leaving it out costs us the whole film's credibility. It goes in
at beat 8, and it is what makes beat 9 land.

---

## BANNED WORDS in any narration
utilise, leverage, performant, mechanism, subsequently, thus, hence, in order to.
Also banned by standing rule: no subtitles, no SRT; on-screen text is 2–3 word fragments only.
