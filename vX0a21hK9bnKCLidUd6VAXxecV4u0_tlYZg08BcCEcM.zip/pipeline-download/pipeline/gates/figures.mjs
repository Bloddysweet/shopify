/* pipeline/gates/figures.mjs — the gate that should have caught the two worst bugs on this project.

   Twice a line gave a number the frame did not carry: "an American home averages one point two"
   with no 1.2 anywhere, and "at week seventy-eight" with an unlabelled rule. Both were caught by
   a person reading stills. That is not a process, that is luck. This gate reads the narration,
   finds every number in it, and requires each one to be on screen as a figure while it is said —
   or waived in the spec, in writing, with a reason.

   Numbers count as carried when any of these is true:
     · a figure with that value is in the on-screen text during the line
     · the line's number IS the target of the shot's count, and the count reaches it during the line
     · the director declared a waiver for that line and number, with a reason
*/

import { openShot, sampleTimes, verdict, F } from './lib.mjs';

const SMALL = {
  zero:0, one:1, two:2, three:3, four:4, five:5, six:6, seven:7, eight:8, nine:9, ten:10,
  eleven:11, twelve:12, thirteen:13, fourteen:14, fifteen:15, sixteen:16, seventeen:17,
  eighteen:18, nineteen:19, twenty:20, thirty:30, forty:40, fifty:50, sixty:60, seventy:70,
  eighty:80, ninety:90, hundred:100, thousand:1000
};

const ONES = { zero:0, one:1, two:2, three:3, four:4, five:5, six:6, seven:7, eight:8, nine:9,
  ten:10, eleven:11, twelve:12, thirteen:13, fourteen:14, fifteen:15, sixteen:16, seventeen:17,
  eighteen:18, nineteen:19, twenty:20, thirty:30, forty:40, fifty:50, sixty:60, seventy:70,
  eighty:80, ninety:90 };

const SCALE = { hundred:100, thousand:1000 };

function parseRun(words) {
  let total = 0, current = 0, sawNumber = false;
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    if (w === 'and') continue;
    if (w === 'a' || w === 'an') {
      const next = words[i + 1];
      if (next && SCALE[next] !== undefined) { current = 1; sawNumber = true; }
      continue;                       /* "a box" is not the number one */
    }
    if (SCALE[w] !== undefined) {
      current = (current || 1) * SCALE[w];
      if (SCALE[w] === 1000) { total += current; current = 0; }
      sawNumber = true;
      continue;
    }
    if (ONES[w] !== undefined) { current += ONES[w]; sawNumber = true; continue; }
    return null;
  }
  return sawNumber ? total + current : null;
}

/* "a hundred and twenty-eight" → 128 · "one point two" → 1.2 · "eighteen" → 18 · "128" → 128 */
export function numbersIn(text) {
  const t = String(text).toLowerCase().replace(/[–—]/g, '-');
  const out = [];

  for (const m of t.matchAll(/\d+(?:\.\d+)?/g)) out.push({ value: +m[0], as: m[0] });

  /* decimals written in words come out first, then the phrase is removed */
  const dec = /\b([a-z]+)\s+point\s+([a-z]+)\b/g;
  for (const m of t.matchAll(dec)) {
    const a = ONES[m[1]], b = ONES[m[2]];
    if (a !== undefined && b !== undefined && a < 100 && b < 10) out.push({ value: +(a + b / 10).toFixed(2), as: m[0] });
  }

  const rest = t.replace(dec, ' ');
  /* a run of number-words is closed by punctuation or by any word that is not a number */
  for (const seg of rest.replace(/[.,;:!?()\[\]"“”]/g, ' | ').split('|')) {
    let run = [];
    const flush = () => { if (run.length) { const v = parseRun(run); if (v !== null && v >= 10) out.push({ value: v, as: run.join(' ') }); } run = []; };
    for (const token of seg.trim().split(/\s+/)) {
      if (!token) continue;
      for (const w of token.split('-')) {
        if (!w) continue;
        if (ONES[w] !== undefined || SCALE[w] !== undefined || w === 'and' || w === 'a' || w === 'an') run.push(w);
        else flush();
      }
    }
    flush();
  }
  /* single digits count too, but only when they are not idiomatic ("one box") */
  return out;
}

const norm = s => String(s).toLowerCase().replace(/[,\s]/g, '');

export async function runFigureGate(spec) {
  const waivers = spec.figure_waivers || [];
  const { page, total, close } = await openShot(spec);

  const findings = [];
  const checked = [];

  for (const line of spec.lines || []) {
    const start = line.in;
    const dur = (line.trim[1] - line.trim[0]);
    const end = Math.min(total, start + dur + 0.4);
    const nums = numbersIn(line.text);
    if (!nums.length) continue;

    const times = sampleTimes(end, 0.2).filter(t => t >= Math.max(0, start - 0.2));
    const shown = new Set();
    /* a counter is a figure that moves: it carries every value it stands on, not only its target.
       So track the range the count passes through while the line is said. */
    let cMin = Infinity, cMax = -Infinity;
    for (const t of times) {
      const boxes = await page.evaluate(x => window.__boxesAt(x), t);
      boxes.forEach(b => shown.add(norm(b.s)));
      if (spec.count) {
        const objs = await page.evaluate(x => window.__audit(x), t);
        const c = objs.objects.filter(o => o.name === spec.count.object).length;
        cMin = Math.min(cMin, c); cMax = Math.max(cMax, c);
      }
    }

    for (const n of nums) {
      const inText = [...shown].some(s => s.includes(String(n.value)) || s.includes(norm(n.as)));
      const isTarget = spec.count && Number.isInteger(n.value) && Math.abs(n.value - spec.count.target) < 0.001;
      /* reached = the count is standing on that value at some point during the line */
      const swept = spec.count && cMax >= cMin && n.value >= cMin && n.value <= cMax;
      const reached = !!isTarget || !!swept;
      const how = inText ? 'on screen' : isTarget ? 'counted to it' : swept ? `count passes it (${cMin}–${cMax})` : null;
      const waived = waivers.find(w => w.line === line.v && Number(w.number) === n.value);

      checked.push({ line: line.v, number: n.value, inText, reached, how, waived: !!waived });

      if (!inText && !reached && !waived)
        findings.push(F('5-figures',
          `line ${line.v} says ${n.value} and nothing on screen stands on ${n.value} while it is said`,
          `put ${n.value} on screen at ${start}s, or waive it in figure_waivers with the reason the drawing carries it`,
          { line: line.v, number: n.value }));
    }
  }
  await close();

  const report = [
    `${checked.length} spoken figure(s) checked`,
    ...checked.map(c => `${c.line}  ${c.number}  ${c.how || (c.waived ? 'waived' : 'MISSING')}`),
    findings.length ? '' : 'no findings'
  ].join('\n');

  return verdict('figures', findings, report);
}
