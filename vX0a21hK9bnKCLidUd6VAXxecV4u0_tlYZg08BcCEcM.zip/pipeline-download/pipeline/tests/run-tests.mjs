/* pipeline/tests/run-tests.mjs — the gates are tested, not trusted.

   Every case is a page that breaks exactly one rule. The gate that owns that rule has to reject
   it, with the right finding. If a gate stops catching its case, the gate is broken, and we find
   out here instead of on a video.

   node pipeline/tests/run-tests.mjs                                                        */

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { runFrameGate } from '../gates/frame.mjs';
import { runFigureGate, numbersIn } from '../gates/figures.mjs';
import { validateSpec } from '../lib/spec.mjs';

const ROOT = path.resolve(new URL('../../', import.meta.url).pathname);
const FIX = path.join(ROOT, 'pipeline/tests/fixtures');
const C = { g: '\x1b[32m', r: '\x1b[31m', d: '\x1b[2m', x: '\x1b[0m', b: '\x1b[1m' };

const spec = name => JSON.parse(fs.readFileSync(path.join(FIX, `${name}.spec.json`), 'utf8'));

const results = [];
const record = (name, ok, detail) => results.push({ name, ok, detail });

/* ---------- the parser, first: everything downstream depends on it ---------- */
{
  const cases = [
    ['A hundred and twenty-eight weeks. For one box.', [128]],
    ['At week seventy-eight, the building is done.', [78]],
    ['An American home averages one point two.', [1.2]],
    ['That rack draws a hundred and twenty kilowatts.', [120]],
    ['Fifty more weeks.', [50]],
    ['Every data centre is waiting on a box.', []],
    ['So the building waits.', []],
    ['1.2 kW each', [1.2]]
  ];
  const bad = cases.filter(([text, want]) => {
    const got = numbersIn(text).map(n => n.value);
    return JSON.stringify(got) !== JSON.stringify(want);
  });
  record('figures · the number parser reads words and digits',
    bad.length === 0,
    bad.map(([t]) => `"${t}" → ${JSON.stringify(numbersIn(t).map(n => n.value))}`).join(' · '));
}


/* ---------- the spec schema: a typo must not pass as a spec ---------- */
{
  const good = spec('margin');
  const bad = [
    ['a misspelt key', { ...good, durration: 4 }, /not a key of a shot spec/],
    ['a missing required block', (() => { const s = { ...good }; delete s.objects; return s; })(), /objects is missing/],
    ['an object with no projection', { ...good, objects: [{ name: 'week', serves: ['l1'], reads_without_caption: 'a square' }] }, /projection is missing/],
    ['a made-up projection', { ...good, objects: [{ name: 'week', projection: 'isometric', serves: ['l1'], reads_without_caption: 'a square' }] }, /not one of/],
    ['a line with no measured in-point', { ...good, lines: [{ v: 'l1', text: 'Does not say when.', trim: [0, 1] }] }, /in is missing/],
    ['a waiver with no reason', { ...good, waivers: [{ gate: '6-rhythm', what: 'holds' }] }, /why is missing/]
  ];
  const missed = bad.filter(([, obj, re]) => !validateSpec(obj).some(f => re.test(f.what)));
  record('spec · the schema rejects a malformed spec', missed.length === 0,
    missed.map(([n]) => `${n}: accepted`).join(' · '));
}
{
  /* a shot that calls itself something other than its folder is a copy, and copies drift */
  const r = validateSpec(spec('margin'), 'some-other-shot');
  record('spec · the spec name must match the folder', r.some(f => /but lives in/.test(f.what)),
    r.map(f => f.what).join(' | ') || 'accepted anything');
}

/* ---------- frame gate ---------- */
{
  const r = await runFrameGate(spec('margin'));
  record('frame · text outside the safe box is rejected', !r.ok && r.findings.some(f => /outside the frame/.test(f.what)),
    r.findings.map(f => f.what).join(' | ') || 'accepted everything');
}
{
  const r = await runFrameGate(spec('sentence'));
  record('frame · a sentence where a fragment belongs is rejected', !r.ok && r.findings.some(f => /not a fragment/.test(f.what)),
    r.findings.map(f => f.what).join(' | ') || 'accepted everything');
}
{
  const r = await runFrameGate(spec('collide'));
  record('frame · text on text is rejected', !r.ok && r.findings.some(f => /text on text/.test(f.what)),
    r.findings.map(f => f.what).join(' | ') || 'accepted everything');
}
{
  const r = await runFrameGate(spec('hold'));   /* a clean frame with nothing wrong should pass */
  record('frame · a clean frame passes', r.ok, r.findings.map(f => f.what).join(' | '));
}

/* ---------- figures gate ---------- */
{
  const r = await runFigureGate(spec('figures'));   /* line says 42, screen says 128 WEEKS */
  record('figures · a spoken number that is not on screen is rejected', !r.ok && r.findings.some(f => f.number === 42),
    r.findings.map(f => f.what).join(' | ') || 'accepted everything');
}

/* a moving counter carries every value it stands on, not only its target */
for (const [name, at, wantPass] of [['inside the sweep', 2.55, true], ['outside the sweep', 0.6, false]]) {
  const s = { ...spec('count'), lines: [{ v: 'l1', text: 'Ten weeks.', file: 'x', trim: [0, 0.8], in: at }] };
  const r = await runFigureGate(s);
  record(`figures · a number ${name} is ${wantPass ? 'carried by the count' : 'not carried by the count'}`,
    r.ok === wantPass, r.report.replace(/\n/g, ' · '));
}

/* ---------- contract gate ---------- */
{
  const m = await import('../gates/contract.mjs');
  const base = spec('hold');
  const r = await m.runContractGate({ ...base, src: 'pipeline/tests/fixtures/contract-missing.html' });
  record('contract · a page missing a hook is named, not crashed on',
    !r.ok && r.findings.some(f => /does not expose window.__boxesAt/.test(f.what)),
    r.findings.map(f => f.what).join(' | ') || 'accepted anything');
}
{
  const m = await import('../gates/contract.mjs');
  const base = spec('hold');
  const r = await m.runContractGate({ ...base, src: 'pipeline/tests/fixtures/count.html', duration: 9 });
  record('contract · a page whose length disagrees with the spec is rejected',
    !r.ok && r.findings.some(f => /the page runs .* and the spec says/.test(f.what)),
    r.findings.map(f => f.what).join(' | ') || 'accepted anything');
}

{
  const m = await import('../gates/contract.mjs');
  const base = spec('hold');
  const r = await m.runContractGate({ ...base, src: 'pipeline/tests/fixtures/missing-asset.html' });
  const named = r.findings.filter(f => /not there: /.test(f.what)).map(f => f.what);
  record('contract · a missing font or image is named by path',
    !r.ok && named.length === 2 && named.some(w => /Ghost-700\.woff2/.test(w)) && named.some(w => /diagram\.png/.test(w)),
    named.join(' | ') || 'accepted everything');
}

/* ---------- voice gate ---------- */
{
  const m = await import('../gates/voice.mjs');
  const base = spec('hold');
  const v = lines => m.runVoiceGate({ ...base, lines });
  const cases = [
    ['a banned word is rejected',
      [{ v: 'l1', text: 'We leverage the grid.', trim: [0, 1], in: 0.2 }], /uses "leverage"/],
    ['an unsourced number is rejected',
      [{ v: 'l1', text: 'It waits a hundred weeks.', trim: [0, 1], in: 0.2 }], /no entry in spec.sources/],
    ['a repeated line is rejected',
      [{ v: 'l1', text: 'One box.', trim: [0, 1], in: 0.2 }, { v: 'l2', text: 'One box.', trim: [0, 1], in: 1.5 }], /says the same thing/],
    ['two voices in the same second are rejected',
      [{ v: 'l1', text: 'First line here.', trim: [0, 2], in: 0.2 }, { v: 'l2', text: 'Second line here.', trim: [0, 2], in: 1.0 }], /before the previous line ends/]
  ];
  const missed = [];
  for (const [name, lines, re] of cases) {
    const r = await v(lines);
    if (r.ok || !r.findings.some(f => re.test(f.what))) missed.push(name);
  }
  record('voice · the words are checked before anything is drawn', missed.length === 0,
    missed.join(' · ') || 'all four accepted');
}
{
  const m = await import('../gates/voice.mjs');
  const base = spec('hold');
  /* a number backed by a source, and a loop that restates its opening line, both pass */
  const ok = await m.runVoiceGate({ ...base, loop: true,
    sources: [{ claim: 'the wait is 128 weeks', url: 'x', numbers: [128] }],
    lines: [{ v: 'l1', text: 'A hundred and twenty-eight weeks.', trim: [0, 1], in: 0.2 },
            { v: 'l2', text: 'A hundred and twenty-eight weeks.', trim: [0, 1], in: 1.6 }] });
  record('voice · a sourced number and a declared loop are allowed', ok.ok, ok.findings.map(f => f.what).join(' | ') || 'ok');
}

/* ---------- scene gate ---------- */
{
  const map = {
    beat: 'fixture', page: 'pipeline/tests/fixtures/count.html', sample: 0.1,
    viewport: { w: 1080, h: 1920 }, overlap_max_px: 60, max_texts: 3, chrome: [],
    safe: { l: 72, r: 1008, t: 56, b: 1690 },
    lines: [{ id: 'l1', say: 'count them' }],
    count: { object: 'week', from: 0.2, to: 2.8, target: 100, max_jump: 4 }
  };
  fs.mkdirSync(path.join(FIX, 'out'), { recursive: true });   /* reports land beside the map, not in fixtures/ */
  const mapFile = path.join(FIX, 'out', 'count.map.json');
  fs.writeFileSync(mapFile, JSON.stringify(map));
  const r = spawnSync(process.execPath, ['pipeline/gates/scene.mjs', map.page, mapFile], { cwd: ROOT, encoding: 'utf8' });
  record('scene · a count that never reaches its target is rejected',
    r.status === 1 && /COUNT NEVER REACHES/.test(r.stdout), (r.stdout || '').split('\n').find(l => l.includes('✗')) || 'accepted everything');
}

/* ---------- motion gate ---------- */
{
  const map = {
    beat: 'fixture', page: 'pipeline/tests/fixtures/hold.html', viewport: { w: 1080, h: 1920 },
    sample: 0.2, cuts: [], holds_max: 0.6, pop_max: 0.08, zoom_max_rate: 0.35, zoom_max_reversals: 0, zoom: []
  };
  fs.mkdirSync(path.join(FIX, 'out'), { recursive: true });
  const mapFile = path.join(FIX, 'out', 'hold.motion.json');
  fs.writeFileSync(mapFile, JSON.stringify(map));
  const r = spawnSync(process.execPath, ['pipeline/gates/motion.mjs', map.page, mapFile], { cwd: ROOT, encoding: 'utf8' });
  record('motion · a dead hold is rejected', r.status === 1 && /DEAD HOLD/.test(r.stdout),
    (r.stdout || '').split('\n').find(l => l.includes('✗')) || 'accepted everything');
}

/* ---------- report ---------- */
const pass = results.filter(r => r.ok).length;
console.log(`\n${C.b}gate tests${C.x} ${results.length} cases\n`);
for (const r of results)
  console.log(`  ${r.ok ? C.g + '✓' + C.x : C.r + '✗' + C.x} ${r.name}${r.ok ? '' : `\n     ${C.d}${r.detail}${C.x}`}`);
console.log(`\n  ${pass}/${results.length} ${pass === results.length ? C.g + 'the gates catch what they claim to catch' + C.x : C.r + 'A GATE IS BROKEN' + C.x}\n`);
process.exit(pass === results.length ? 0 : 1);
