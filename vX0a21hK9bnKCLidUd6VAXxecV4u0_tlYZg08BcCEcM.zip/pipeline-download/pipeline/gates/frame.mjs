/* pipeline/gates/frame.mjs — the frame and the type.
   Replaces internet/qa.mjs for pipeline shots. Everything it asserts is read from the spec:
   the safe box, the fragment limit, the chrome. It also enforces the rule no tool was checking:
   on-screen text is a fragment, not a sentence. */

import { openShot, safeBox, sampleTimes, verdict, F } from './lib.mjs';

const words = s => s.trim().split(/\s+/).filter(Boolean).length;

export async function runFrameGate(spec) {
  const SAFE = safeBox(spec);
  const maxTexts = spec.gates?.mechanical?.max_texts ?? 3;
  const maxWords = spec.gates?.mechanical?.max_words ?? 3;
  const chrome = new Set(spec.gates?.mechanical?.chrome || []);
  const isChrome = s => chrome.has(String(s).trim());

  const { page, total, close } = await openShot(spec);
  const times = sampleTimes(total, 0.1);
  const rows = [];
  for (const t of times) rows.push({ t, boxes: await page.evaluate(x => window.__boxesAt(x), t) });
  await close();

  const findings = [];
  const seen = new Set();
  const add = (what, fix, at, evidence) => {
    const k = what + '|' + Math.round(at * 2);
    if (seen.has(k)) return;
    seen.add(k);
    findings.push(F('3-frame', what, fix, { at: `${at}s`, evidence }));
  };

  for (const { t, boxes } of rows) {
    const frags = boxes.filter(b => !isChrome(b.s));

    if (frags.length > maxTexts)
      add(`${frags.length} text fragments on screen`, `no more than ${maxTexts}: ${frags.map(b => b.s).join(' / ')}`, t);

    for (const b of boxes) {
      if (b.x0 < SAFE.l - 0.5 || b.x1 > SAFE.r + 0.5 || b.y0 < SAFE.t - 0.5 || b.y1 > SAFE.b + 0.5)
        add(`text outside the frame: "${b.s}"`, `keep it inside l${SAFE.l} r${SAFE.r} t${SAFE.t} b${SAFE.b}`, t,
          [b.x0, b.y0, b.x1, b.y1].map(v => Math.round(v)).join(','));
      if (!isChrome(b.s) && words(b.s) > maxWords)
        add(`a sentence, not a fragment: "${b.s}" (${words(b.s)} words)`, `cut it to ${maxWords} words or fewer`, t);
    }

    for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
      const A = boxes[i], B = boxes[j];
      const ox = Math.min(A.x1, B.x1) - Math.max(A.x0, B.x0);
      const oy = Math.min(A.y1, B.y1) - Math.max(A.y0, B.y0);
      if (ox > 1.5 && oy > 1.5) add(`text on text: "${A.s}" over "${B.s}"`, 'move one of them', t, `${Math.round(ox)}x${Math.round(oy)}`);
    }
  }

  const report = [
    `${times.length} samples · safe l${SAFE.l} r${SAFE.r} t${SAFE.t} b${SAFE.b} · max ${maxTexts} fragments of ${maxWords} words`,
    findings.length ? findings.map(f => `${f.at}  ✗ ${f.what}`).join('\n') : 'no findings'
  ].join('\n');

  return verdict('frame', findings, report);
}
