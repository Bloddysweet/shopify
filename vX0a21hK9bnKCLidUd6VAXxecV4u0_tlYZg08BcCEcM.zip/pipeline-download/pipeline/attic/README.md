# attic

`critic.mjs` — the first critic. It rendered stills, scored them against a numeric threshold, and
passed work that a person could see was wrong. It was replaced because a score is not a judgement:
frame, scene, figures and motion ask specific questions now, and each has a test in pipeline/tests.

Kept only because deleting history loses the reason it was wrong.
