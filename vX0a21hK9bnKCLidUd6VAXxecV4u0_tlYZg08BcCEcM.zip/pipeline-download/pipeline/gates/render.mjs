/* pipeline/gates/render.mjs — the drawing, frame by frame, into a film.

   The page is a function of time (see PAGE.md), so rendering is a loop: draw t, screenshot, pipe
   to ffmpeg. Nothing here knows about any particular shot — the viewport, the length and the
   frame rate come from the spec.

   node pipeline/gates/render.mjs <page.html> <out.mp4> <fps> <w> <h>                        */

import puppeteer from 'puppeteer';
import path from 'node:path';
import { spawn } from 'node:child_process';
import ffmpegPath from 'ffmpeg-static';

const [, , file, out, fpsArg, wArg, hArg] = process.argv;
const FPS = parseFloat(fpsArg || '30');

const browser = await puppeteer.launch({
  args: ['--no-sandbox', '--disable-dev-shm-usage', '--force-color-profile=srgb', '--font-render-hinting=none']
});
const page = await browser.newPage();

/* the viewport is given, or taken from the page itself */
let VW = wArg ? +wArg : null, VH = hArg ? +hArg : null;
if (!VW || !VH) {
  await page.goto('file://' + path.resolve(file), { waitUntil: 'load' });
  const own = await page.evaluate(() => ({
    w: parseInt(getComputedStyle(document.body).width),
    h: parseInt(getComputedStyle(document.body).height)
  }));
  VW = VW || own.w || 1080; VH = VH || own.h || 1920;
}
await page.setViewport({ width: VW, height: VH, deviceScaleFactor: 1 });
await page.goto('file://' + path.resolve(file), { waitUntil: 'load' });
await page.waitForFunction('window.__ready===true');
await page.evaluate(() => document.fonts.ready);

const total = await page.evaluate(() => window.__total());
const frames = Math.round(total * FPS);

const ff = spawn(ffmpegPath, ['-y', '-f', 'image2pipe', '-framerate', String(FPS), '-i', '-',
  '-c:v', 'libx264', '-preset', 'slow', '-crf', '18', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', out],
  { stdio: ['pipe', 'inherit', 'inherit'] });

for (let i = 0; i < frames; i++) {
  await page.evaluate(x => window.__draw(x), i / FPS);
  const buf = await page.screenshot({ type: 'png', optimizeForSpeed: true });
  if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
}
ff.stdin.end();
await new Promise(r => ff.on('close', r));
await browser.close();
console.log(`${frames} frames at ${VW}x${VH} → ${out}`);
