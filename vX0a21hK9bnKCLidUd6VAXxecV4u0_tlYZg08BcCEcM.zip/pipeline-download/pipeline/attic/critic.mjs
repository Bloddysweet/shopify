/* critic.mjs — the strict reviewer in the pipeline.

   The rule this enforces: an image is not finished when it looks good to the person who made
   it. It is finished when a reviewer, given the audio line and the frame, says the frame shows
   what the line says — and finds nothing else wrong with it.

   This tool does the half a machine can do honestly:
     · geometry      — text out of safe area, text overlapping text
     · discipline    — more than three text fragments in a frame
     · colour budget — the accent must appear once, and only once
     · emptiness     — a frame that is mostly void is a frame that says nothing
     · clutter       — a frame packed edge to edge has no focus
     · edge bleed    — marks running off the frame
     · continuity    — the frame must change when the audio does, and not before

   It prints, for every sampled frame, the audio line that is playing and the claim the frame
   makes about itself, so the human half — does the picture say what the sentence says — can be
   judged against evidence instead of memory.

   Usage:  node critic/critic.mjs src/beat1.html critics/beat1.map.json
   Exit 1 means: do not proceed to the next beat.                                        */

import puppeteer from 'puppeteer';
import { PNG } from 'pngjs';
import fs from 'node:fs';
import path from 'node:path';

const [, , HTML, MAP] = process.argv;
const map = JSON.parse(fs.readFileSync(MAP, 'utf8'));

const SAFE = { l: 40, r: 1240, t: 28, b: 672 };
const ACCENT = { r: 255, g: 90, b: 31 };
const FG_TOL = 16;          // colour distance from background that counts as ink
const ACCENT_TOL = 46;

const browser = await puppeteer.launch({
  args: ['--no-sandbox', '--disable-dev-shm-usage', '--force-color-profile=srgb', '--font-render-hinting=none'],
});
const page = await browser.newPage();
page.on('pageerror', e => console.log('PAGEERROR:', e.message));
await page.setViewport({ width: 1300, height: 740, deviceScaleFactor: 1 });
await page.goto('file://' + path.resolve(HTML), { waitUntil: 'load' });
await page.waitForFunction('window.__ready===true');
await page.evaluate(() => document.fonts.ready);

const total = await page.evaluate(() => window.__total());
const hasClaim = await page.evaluate(() => typeof window.__claim === 'function');

// ---- sample points: every declared shot change, plus a few inside each stretch of speech
const samples = [...new Set(map.samples.map(s => +s.t.toFixed(2)))].sort((a, b) => a - b);

const dist = (r, g, b, c) => Math.sqrt((r - c.r) ** 2 + (g - c.g) ** 2 + (b - c.b) ** 2);

function analyse(png) {
  const { width: W, height: H, data } = png;
  const counts = new Map();
  for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) {
    const i = (y * W + x) * 4;
    const k = (data[i] >> 3) + ',' + (data[i + 1] >> 3) + ',' + (data[i + 2] >> 3);
    counts.set(k, (counts.get(k) || 0) + 1);
  }
  let bgKey = null, best = -1;
  for (const [k, v] of counts) if (v > best) { best = v; bgKey = k; }
  const [br, bg2, bb] = bgKey.split(',').map(n => (n << 3) + 4);

  let ink = 0, accent = 0, edge = 0;
  const L = new Uint8Array(H), R = new Uint8Array(H), T = new Uint8Array(W), Bm = new Uint8Array(W);
  const GX = 4, GY = 3, cell = new Array(GX * GY).fill(0);
  const cellTot = new Array(GX * GY).fill(0);
  const accentPts = [];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4;
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const cx = Math.min(GX - 1, Math.floor(x / (W / GX)));
    const cy = Math.min(GY - 1, Math.floor(y / (H / GY)));
    const ci = cy * GX + cx;
    cellTot[ci]++;
    if (dist(r, g, b, { r: br, g: bg2, b: bb }) > FG_TOL) {
      ink++; cell[ci]++;
      if (x < 2) L[y] = 1;
      if (x > W - 3) R[y] = 1;
      if (y < 2) T[x] = 1;
      if (y > H - 3) Bm[x] = 1;
    }
    if (dist(r, g, b, ACCENT) < ACCENT_TOL) { accent++; accentPts.push([x, y]); }
  }
  const dead = cell.map((v, i) => v / cellTot[i] < 0.004 ? i : -1).filter(i => i >= 0);
  /* EDGE BLEED, properly: an object cut off at the frame shows up as a long unbroken run of
     ink on one edge with nothing matching it on the opposite edge. Ground lines, horizons and
     hatching produce runs that either continue across the frame or are a couple of pixels long. */
  const runs = (arr, min) => {
    const out = []; let i = 0;
    while (i < arr.length) {
      if (!arr[i]) { i++; continue; }
      let j = i; while (j < arr.length && arr[j]) j++;
      if (j - i >= min) out.push([i, j]); i = j;
    }
    return out;
  };
  const paired = (a, b) => {
    let n = 0;
    for (const [s0, s1] of a) if (b.slice(s0, s1).some(v => v)) n += s1 - s0;
    return n;
  };
  const MINRUN = 14;
  const lr = runs(L, MINRUN), rr = runs(R, MINRUN), tr = runs(T, MINRUN), btm = runs(Bm, MINRUN);
  const bleedL = paired(lr, R) + paired(rr, L) + paired(tr, Bm) + paired(btm, T);
  const total = lr.concat(rr, tr, btm).reduce((a, [s0, s1]) => a + (s1 - s0), 0);
  edge = Math.max(0, total - bleedL);
  return { W, H, ink: ink / (W * H), accent: accent / (W * H), edge, accentPts, dead, data, br, bg2, bb };
}

// largest accent cluster, so a single icon split across pixels still counts as one thing
function clusters(pts) {
  if (!pts.length) return 0;
  const step = Math.max(1, Math.floor(pts.length / 4000));
  const sample = pts.filter((_, i) => i % step === 0);
  const seen = new Set(); let groups = 0;
  const near = (a, b) => Math.abs(a[0] - b[0]) < 90 && Math.abs(a[1] - b[1]) < 90;
  for (let i = 0; i < sample.length; i++) {
    if (seen.has(i)) continue;
    groups++; const stack = [i]; seen.add(i);
    while (stack.length) {
      const cur = stack.pop();
      for (let j = 0; j < sample.length; j++) {
        if (seen.has(j)) continue;
        if (near(sample[cur], sample[j])) { seen.add(j); stack.push(j); }
      }
    }
  }
  return groups;
}

const rows = [];
for (const t of samples) {
  await page.evaluate(T => window.__draw(T), t);
  const boxes = await page.evaluate(T => window.__boxesAt(T), t);
  const claim = hasClaim ? await page.evaluate(T => window.__claim(T), t) : '(none declared)';
  const buf = await page.screenshot({ clip: { x: 0, y: 0, width: 1300, height: 740 } });
  const png = PNG.sync.read(buf);
  const m = analyse(png);

  const problems = [];
  // geometry
  for (const b of boxes) {
    if (b.x0 < SAFE.l - 0.5 || b.x1 > SAFE.r + 0.5 || b.y0 < SAFE.t - 0.5 || b.y1 > SAFE.b + 0.5)
      problems.push(`TEXT OUT OF SAFE AREA — "${b.s}"`);
  }
  for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
    const A = boxes[i], B = boxes[j];
    const ox = Math.min(A.x1, B.x1) - Math.max(A.x0, B.x0);
    const oy = Math.min(A.y1, B.y1) - Math.max(A.y0, B.y0);
    if (ox > 1.5 && oy > 1.5) problems.push(`TEXT OVERLAP — "${A.s}" <> "${B.s}"`);
    else if (ox > 1.5 && oy > -8) problems.push(`TEXT TOO TIGHT — "${A.s}" <> "${B.s}"`);
  }
  // text must sit on its own quiet ground, not on top of the drawing
  for (const b of boxes) {
    const PAD = 14;
    let ring = 0, tot = 0;
    for (let y = Math.max(0, Math.floor(b.y0 - PAD)); y < Math.min(m.H, Math.ceil(b.y1 + PAD)); y++)
      for (let x = Math.max(0, Math.floor(b.x0 - PAD)); x < Math.min(m.W, Math.ceil(b.x1 + PAD)); x++) {
        const inBox = x >= b.x0 - 2 && x <= b.x1 + 2 && y >= b.y0 - 2 && y <= b.y1 + 2;
        if (inBox) continue;
        const i = (y * m.W + x) * 4; tot++;
        if (dist(m.data[i], m.data[i + 1], m.data[i + 2], { r: m.br, g: m.bg2, b: m.bb }) > FG_TOL) ring++;
      }
    const dens = tot ? ring / tot : 0;
    if (dens > 0.10) problems.push(`NO QUIET GROUND FOR TEXT — "${b.s}" (${(dens * 100).toFixed(0)}% ink crowding it)`);
  }

  // discipline
  if (boxes.length > 3) problems.push(`TOO MANY TEXT FRAGMENTS — ${boxes.length} on screen (max 3)`);
  // colour budget
  const nc = clusters(m.accentPts);
  if (m.accent > 0.055) problems.push(`ACCENT OVERUSED — ${(m.accent * 100).toFixed(1)}% of frame`);
  if (nc > 1) problems.push(`ACCENT IN ${nc} PLACES — the accent must point at one thing`);
  // emptiness / clutter
  if (m.ink < 0.012) problems.push(`FRAME IS EMPTY — ${(m.ink * 100).toFixed(2)}% of pixels carry anything`);
  if (m.ink > 0.55) problems.push(`FRAME IS CLUTTERED — ${(m.ink * 100).toFixed(1)}% of pixels carry something`);
  if (m.dead.length >= 3) problems.push(`DEAD SPACE — ${m.dead.length} of 12 zones carry almost nothing; the frame is mostly void`);
  // edge bleed
  if (m.edge > 40) problems.push(`MARKS CROSS THE FRAME EDGE — ${m.edge} px on the border`);

  const line = map.lines.find(l => t >= l.from && t < l.to);
  const waiver = line && line.waiver ? line.waiver : null;
  let waived = null;
  if (waiver) {
    const before = problems.length;
    for (let i = problems.length - 1; i >= 0; i--)
      if (problems[i].startsWith(waiver.rule)) { problems.splice(i, 1); waived = waiver; }
  }
  rows.push({ t, claim, audio: lineAt(map, t), boxes: boxes.length, ink: m.ink, accent: m.accent,
              clusters: nc, problems, png, waived });
}

function lineAt(map, t) {
  const s = map.lines.find(l => t >= l.from && t < l.to);
  return s ? s.say : '';
}

// ---- report
const fails = rows.filter(r => r.problems.length);
const out = [];
out.push(`CRITIC — ${path.basename(HTML)}`);
out.push(`${rows.length} frames sampled across ${total}s · ${fails.length} rejected\n`);
for (const r of rows) {
  out.push(`t=${r.t.toFixed(1)}s`);
  out.push(`  audio : "${r.audio}"`);
  out.push(`  claim : "${r.claim}"`);
  out.push(`  stats : ink ${(r.ink * 100).toFixed(2)}%  accent ${(r.accent * 100).toFixed(2)}%  clusters ${r.clusters}  text ${r.boxes}`);
  if (r.waived) out.push(`  ~ waived by brief: ${r.waived.rule} — ${r.waived.why}`);
  if (r.problems.length) r.problems.forEach(p => out.push(`  ✗ ${p}`));
  else out.push(`  ✓ passes the mechanical checks`);
  out.push('');
}
const waivedCount = rows.filter(r => r.waived).length;
const verdict = fails.length ? 'REJECTED — do not proceed'
  : (waivedCount ? `PASSED MECHANICAL — ${waivedCount} frame(s) waived by brief. SEMANTIC REVIEW STILL REQUIRED.` : 'PASSED — may proceed');
out.push(`VERDICT: ${verdict}`);
const text = out.join('\n');
console.log(text);
fs.writeFileSync(path.resolve(path.dirname(MAP), 'critique-report.txt'), text);

// contact sheet, captioned with audio + claim + verdict
const sheetW = 1300, rowH = 740 + 74;
const { PNG: P2 } = await import('pngjs');
const sheet = new P2({ width: sheetW, height: rowH * rows.length });
// blank the canvas
for (let i = 0; i < sheet.data.length; i += 4) { sheet.data[i] = 8; sheet.data[i + 1] = 9; sheet.data[i + 2] = 11; sheet.data[i + 3] = 255; }
rows.forEach((r, idx) => {
  const src = r.png;
  const oy = idx * rowH + 74;
  for (let y = 0; y < 740; y++) for (let x = 0; x < 1300; x++) {
    const si = (y * 1300 + x) * 4, di = ((oy + y) * sheetW + x) * 4;
    sheet.data[di] = src.data[si]; sheet.data[di + 1] = src.data[si + 1]; sheet.data[di + 2] = src.data[si + 2];
  }
});
fs.writeFileSync(path.resolve(path.dirname(MAP), 'critique-frames.png'), P2.sync.write(sheet));

await browser.close();
process.exit(fails.length ? 1 : 0);
