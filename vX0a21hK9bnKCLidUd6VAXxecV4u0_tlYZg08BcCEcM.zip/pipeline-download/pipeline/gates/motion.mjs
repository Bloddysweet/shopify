/* motion.mjs — the critic for the animation, not for the stills.
   The image critic asks "is this frame right". This one asks "is this move right":
   does anything get cut off by the camera, does the camera move without a reason,
   does it hunt, does anything pop, does the frame sit dead for too long.

      Takes the same spec-derived map as the scene gate. exit 1 = rejected               */
import puppeteer from 'puppeteer';
import { PNG } from 'pngjs';
import path from 'node:path';
import fs from 'node:fs';

const [,, FILE, MAPFILE] = process.argv;
const MAP = JSON.parse(fs.readFileSync(MAPFILE, 'utf8'));
const STEP = MAP.sample || 0.2;

const browser = await puppeteer.launch({
  args: ['--no-sandbox', '--disable-dev-shm-usage', '--force-color-profile=srgb', '--font-render-hinting=none']
});
const page = await browser.newPage();
const VP = MAP.viewport || { w: 1300, h: 740 };
await page.setViewport({ width: VP.w, height: VP.h, deviceScaleFactor: 1 });
await page.goto('file://' + path.resolve(FILE), { waitUntil: 'load' });
await page.waitForFunction('window.__ready===true');
await page.evaluate(() => document.fonts.ready);
const total = await page.evaluate(() => window.__total());

/* ---------- measure one frame ---------- */
function measure(buf) {
  const png = PNG.sync.read(buf);
  const { width: W, height: H, data } = png;
  const bg = [data[0], data[1], data[2]];
  const inkAt = (x, y) => {
    const i = (y * W + x) * 4;
    const d = Math.abs(data[i] - bg[0]) + Math.abs(data[i + 1] - bg[1]) + Math.abs(data[i + 2] - bg[2]);
    return d > 18 ? 1 : 0;
  };
  /* how much ink sits on each of the four edges */
  const L = new Uint8Array(H), R = new Uint8Array(H), T = new Uint8Array(W), B = new Uint8Array(W);
  let ink = 0;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (!inkAt(x, y)) continue;
    ink++;
    if (x < 2) L[y] = 1;
    else if (x > W - 3) R[y] = 1;
    if (y < 2) T[x] = 1;
    else if (y > H - 3) B[x] = 1;
  }
  const runs = (arr, min) => {
    const out = []; let i = 0;
    while (i < arr.length) {
      if (!arr[i]) { i++; continue; }
      let j = i; while (j < arr.length && arr[j]) j++;
      if (j - i >= min) out.push([i, j]); i = j;
    }
    return out;
  };
  /* a mark that runs across the frame is the sheet (horizon, ground). A mark that enters and
     stops is an object the camera has cut. */
  const MINRUN = 10;
  const lr = runs(L, MINRUN), rr = runs(R, MINRUN), tr = runs(T, MINRUN), br = runs(B, MINRUN);
  const paired = (a, b) => {
    let n = 0;
    for (const [s0, s1] of a) if (b.slice(s0, s1).some(v => v)) n += s1 - s0;
    return n;
  };
  const overlapL = paired(lr, R) + paired(rr, L);
  const overlapT = paired(tr, B) + paired(br, T);
  const sum = a => a.reduce((s, [s0, s1]) => s + (s1 - s0), 0);
  const clip = Math.max(0, sum(lr) + sum(rr) - overlapL) + Math.max(0, sum(tr) + sum(br) - overlapT);

  /* a coarse signature so we can tell whether anything changed at all */
  /* a sparse luminance map: two pixels in three, so a 1 px tick is not missed and the
     count is honestly "how much of the frame changed" */
  const STRIDE = 2, SW = Math.floor(W / STRIDE), SH = Math.floor(H / STRIDE);
  const sig = new Float64Array(SW * SH);
  for (let y = 0; y < SH; y++) for (let x = 0; x < SW; x++) {
    const i = ((y * STRIDE) * W + x * STRIDE) * 4;
    sig[y * SW + x] = (data[i] + data[i + 1] + data[i + 2]) / 765;
  }
  return { W, H, ink: ink / (W * H), clip, sig };
}
/* fraction of the frame that visibly changed: a 2 px tick appearing in a 10 px cell counts,
   a slow fade of the whole frame barely does. Area, not brightness. */
const diff = (a, b) => {
  let n = 0;
  for (let i = 0; i < a.length; i++) if (Math.abs(a[i] - b[i]) > 0.05) n++;
  return n / a.length;
};

/* ---------- sweep ---------- */
const samples = [];
for (let t = 0; t <= total + 1e-9; t += STEP) {
  const T = +t.toFixed(3);
  await page.evaluate(x => window.__draw(x), T);
  const cam = await page.evaluate(x => window.__cam(x), T);
  const buf = await page.screenshot({ type: 'png', optimizeForSpeed: true });
  const m = measure(buf);
  samples.push({ t: T, cam, ...m });
}
await browser.close();

/* ---------- the rules ---------- */
const problems = [];
const near = (t, list, tol = STEP * 1.5) => list.some(c => Math.abs(c - t) <= tol);
const isCut = t => near(t, MAP.cuts || []);

/* 1. nothing may be cut by the camera */
let clipRun = null;
for (const s of samples) {
  if (s.clip > 8) {
    if (!clipRun) clipRun = { t0: s.t, t1: s.t, worst: s.clip, z: s.cam.z };
    else { clipRun.t1 = s.t; clipRun.worst = Math.max(clipRun.worst, s.clip); }
    clipRun.z = Math.max(clipRun.z, s.cam.z);
  } else if (clipRun) { problems.push({ rule: 'CAMERA CUTS THE PICTURE', ...clipRun }); clipRun = null; }
}
if (clipRun) problems.push({ rule: 'CAMERA CUTS THE PICTURE', ...clipRun });

/* 2. a zoom has to be declared in the motion map, with a reason */
const declared = MAP.zoom || [];
const insideDeclared = t => declared.some(d => t >= d.from - STEP && t <= d.to + STEP);
let zRun = null;
for (let i = 1; i < samples.length; i++) {
  const a = samples[i - 1], b = samples[i];
  const dz = b.cam.z - a.cam.z;
  if (Math.abs(dz) > 0.004 && !insideDeclared(b.t)) {
    if (!zRun) zRun = { t0: a.t, t1: b.t, from: a.cam.z, to: b.cam.z, view: b.cam.view };
    else { zRun.t1 = b.t; zRun.to = b.cam.z; }
  } else if (zRun) { problems.push({ rule: 'UNDECLARED CAMERA MOVE', ...zRun }); zRun = null; }
}
if (zRun) problems.push({ rule: 'UNDECLARED CAMERA MOVE', ...zRun });

/* 3. the camera may not move faster than the eye can follow */
for (const d of declared) {
  const inRange = samples.filter(s => s.t >= d.from && s.t <= d.to + 1e-9);
  if (inRange.length < 2) continue;
  const span = inRange[inRange.length - 1].t - inRange[0].t || 1;
  const rate = Math.abs(inRange[inRange.length - 1].cam.z - inRange[0].cam.z) / span;
  if (rate > (MAP.zoom_max_rate || 0.35))
    problems.push({ rule: 'CAMERA MOVES TOO FAST', t0: d.from, t1: d.to, rate: +rate.toFixed(2) });
}

/* 4. the camera may not hunt: one direction, then stop */
{
  let dir = 0, reversals = 0, at = null;
  for (let i = 1; i < samples.length; i++) {
    const dz = samples[i].cam.z - samples[i - 1].cam.z;
    if (Math.abs(dz) < 0.003) continue;
    const nd = Math.sign(dz);
    if (dir !== 0 && nd !== dir) { reversals++; at = samples[i].t; }
    dir = nd;
  }
  if (reversals > (MAP.zoom_max_reversals ?? 1))
    problems.push({ rule: 'CAMERA HUNTS', reversals, at });
}

/* 5. a frame that does not change for too long is a dead hold */
{
  let still = samples[0].t;
  for (let i = 1; i < samples.length; i++) {
    const d = diff(samples[i - 1].sig, samples[i].sig);
    if (d < 0.00005 && !isCut(samples[i].t)) {
      if (samples[i].t - still > (MAP.holds_max || 4))
        { problems.push({ rule: 'DEAD HOLD', t0: +still.toFixed(1), t1: samples[i].t }); still = samples[i].t; }
    } else still = samples[i].t;
  }
}

/* 6. nothing may jump in one step unless it is a declared cut */
for (let i = 1; i < samples.length; i++) {
  const d = diff(samples[i - 1].sig, samples[i].sig);
  if (d > (MAP.pop_max || 0.10) && !isCut(samples[i].t))
    problems.push({ rule: 'POP — the frame jumps', t0: samples[i - 1].t, t1: samples[i].t, amount: +d.toFixed(3) });
}

/* ---------- report ---------- */
const uniq = [];
const seen = new Set();
for (const p of problems) {
  const k = p.rule + '|' + Math.round(p.t0 * 2);
  if (seen.has(k)) continue;
  seen.add(k); uniq.push(p);
}

const L = [];
L.push(`MOTION CRITIC — ${path.basename(FILE)}`);
L.push(`${samples.length} frames sampled every ${STEP}s across ${total}s · ${uniq.length} finding(s)`);
L.push('');
const rng = o => o.t0 !== undefined ? `${o.t0.toFixed(1)}–${o.t1.toFixed(1)}s` : '';
for (const p of uniq) {
  L.push(`${rng(p)}  ✗ ${p.rule}`);
  if (p.rule === 'CAMERA CUTS THE PICTURE') L.push(`         ${p.worst} px of drawing enter an edge and stop · camera z ${p.z}`);
  if (p.rule === 'UNDECLARED CAMERA MOVE') L.push(`         ${p.view} view, z ${p.from} → ${p.to}, not in the motion map`);
  if (p.rule === 'CAMERA MOVES TOO FAST') L.push(`         ${p.rate} per second (limit ${MAP.zoom_max_rate})`);
  if (p.rule === 'CAMERA HUNTS') L.push(`         ${p.reversals} direction changes`);
  if (p.rule === 'DEAD HOLD') L.push(`         nothing changed for ${(p.t1 - p.t0).toFixed(1)}s (limit ${MAP.holds_max}s)`);
  if (p.rule === 'POP — the frame jumps') L.push(`         ${p.amount} of the frame changed in ${STEP}s (limit ${MAP.pop_max})`);
  L.push('');
}
const camLine = samples.filter((_, i) => i % Math.round(1 / STEP) === 0)
  .map(s => `${Math.round(s.t)}s z${s.cam.z}`).join(' · ');
L.push(`camera: ${camLine}`);
const perSec = [];
for (let i = 1; i < samples.length; i++) {
  const sec = Math.floor(samples[i].t);
  const d = diff(samples[i - 1].sig, samples[i].sig);
  perSec[sec] = Math.max(perSec[sec] || 0, d);
}
L.push("change per second (‰ of frame): " + perSec.map((d, s) => `${s}:${(d * 1000).toFixed(1)}`).join(" · "));
L.push('');
L.push(uniq.length ? 'VERDICT: REJECTED — fix the move, then re-run' : 'VERDICT: PASSED — the motion is clean');
fs.mkdirSync(path.dirname(path.join(path.dirname(MAPFILE), 'motion-report.txt')), { recursive: true });
fs.writeFileSync(path.join(path.dirname(MAPFILE), 'motion-report.txt'), L.join('\n'));
console.log(L.join('\n'));
process.exit(uniq.length ? 1 : 0);
