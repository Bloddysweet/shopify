# notes — what moved, and why

## the old critics, and where they went

| old | was | now | why it moved |
|---|---|---|---|
| `ep01/critic/critic.mjs` | rendered stills, scored them, passed anything over a threshold | `pipeline/attic/critic.mjs` | a score is not a judgement. It passed work a person could see was wrong |
| `ep01/critic/scene.mjs` | read the drawn objects: allowed, serving, contained, countable | `pipeline/gates/scene.mjs` | one folder of gates, one map built from the spec by `lib/ladder.mjs` |
| `ep01/critic/motion.mjs` | cuts, pops, dead holds, camera hunting | `pipeline/gates/motion.mjs` | same |
| `internet/qa.mjs` | frame and type check, with its own safe box | `pipeline/gates/frame.mjs` | it carried its own copy of the margins, so it disagreed with the other critics about the same picture |
| — | — | `pipeline/gates/figures.mjs` | new: every number the voice says has to be on screen while it is said |

**The root cause of contradictory verdicts was that three critics each held their own idea of the safe
box, the viewport and "text".** `gates/lib.mjs` reads all of that from the shot spec, so there is one
definition, and changing it changes every gate at once.

## what is enforced now that was not before

- **the gates are tested** — `run.mjs test`, 12 fixtures, one broken rule each; `all` refuses to start if a gate stops catching its own case.
- **the spec is schema-checked** — `schema/spec.schema.json`, with `additionalProperties: false`, so a misspelt key is a finding instead of a silent no-op.
- **a pass expires** — every pass records the gate version, the spec hash and the drawing hash. Change any of them and the pass goes stale, visibly, with the reason.
- **a judgement gate cannot be self-generated** — `reading` and `rhythm` only move on a signed verdict whose `agent` matches the stage owner.
- **the report carries its own evidence** — `report.html` has one frame per line, at the middle of the line, inlined so it opens anywhere.

## what was still tied to one project, and is not any more

| was | now |
|---|---|
| `encode` called `ep01/build/render.mjs` | `pipeline/gates/render.mjs`, viewport and length from the spec |
| the `sound` gate was inline in `ladder.mjs` | `pipeline/gates/sound.mjs` |
| the page contract was folklore, in one shot's html | `pipeline/PAGE.md` + `gates/contract.mjs`, which names the missing hook instead of crashing |
| a new shot started as a copy of an old one | `run.mjs new`, which writes a legal spec and a contract-satisfying page |
| banned words were a house rule people remembered | `gates/voice.mjs`, enforced before anything is drawn |
| a figure "traced to a source" by hand | `gates/voice.mjs` requires the number in `sources[].numbers`, or the arithmetic in `derivation` |
| nothing checked that the machine could run the line | `run.mjs doctor` |

There is no path in `pipeline/` that reaches into `ep01/` any more. Any shot in any folder is the same
to the line.

## found on first real run

- **t01, line 6**: the voice says *"fifty more weeks"* while the counter is standing on 116. The number is
  named and never reached. Nine passes had already been earned on that shot.
- **s04 spec**: `shot` was a path, not an id; `episode` was an integer where the other spec had a string;
  an object declared `projection: "none"`; `approval.state` was `"gated"`, a state the ladder does not have.
  All four had gone unnoticed through every gate.
- **t01 spec**: `episode: null`. Removed — a standalone short has no episode.
- **the scaffold itself**: the meter baseline sat at `y=1690`, which is the safe line, so the text's
  box hung 6 px below it. The frame gate rejected the pipeline's own template on its first run, which
  is the correct outcome.

Two of those were mine, and both were invisible until something asked.
