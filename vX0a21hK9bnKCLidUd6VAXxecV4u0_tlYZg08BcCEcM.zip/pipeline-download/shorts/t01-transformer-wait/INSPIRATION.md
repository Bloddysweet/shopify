# what travelled, and what was taken from it

The brief: find animated shorts on YouTube past ten million views, and take inspiration. Inspiration
is not imitation — nothing below is a style, a character or a colour. What was taken is structure.

## the references

| piece | views | why it was chosen |
|---|---|---|
| **Kurzgesagt — The Egg** (2019) | **36.2M** | the highest like-to-view ratio in the sample (~5.5 %); the outlier where the house style is deliberately slowed down |
| **Kurzgesagt — What If You Fall into a Black Hole?** | 10M+ | the reference for scale management |
| **Kurzgesagt — The Fermi Paradox** | 10M+ | the reference for making a number carry an argument |
| Kurzgesagt channel, overall | 3.6B total · 10–30M per video · 23–25M subs | the only channel in this niche that reliably clears ten million |

Sources: [motion-graphics atlas](https://motion-graphics-atlas.nileshknt1.chatgpt.site/) (The Egg,
36,220,464 views, ~5.52 % likes/views), [moonb.io analysis](https://www.moonb.io/blog/animated-educational-videos)
(technique reading), [becomeviral case study](https://becomeviral.com/blog/kurzgesagt-case-study)
(retention economics, 10–30M per video).

## the five things taken

**1. One idea on screen at a time.** Their black-hole piece is described as "never more than one physics
idea on screen at once". Ours shows exactly one idea for its whole length: a wait, measured in weeks.
There is no second diagram, no inset, no supporting chart.

**2. Every abstract jump gets a concrete handhold first.** Their distances and forces are re-anchored
against "a tiny human figure or a single line of motion". Ours is a number nobody can feel — *128
weeks* — so it is re-anchored as **128 squares you can count**, and the 18-month claim is anchored
against a building standing on the same ground line at the same scale. The viewer is never asked to
imagine a duration; they are given one to watch.

**3. The diagram does the reasoning.** In The Fermi Paradox "you watch the logic narrow". Here the
reasoning is a position, not a shape: the field fills, a rule lands at week 78 where the building
finishes, and everything after it arrives in the accent. The argument is *visible before it is
explained* — by 15.1 s you can see that most of the wait happens after the building is done, and the
narration is confirming what you already read.

**4. Restraint beats busy, and holds are a craft decision.** The Egg is praised for "holds on wide
empty frames for seconds at a time" and letting the writing set the tempo. This is the technique that
cost the most argument with our own gate: our motion critic fails any hold over 1.2 s, so this shot
carries a **declared waiver** permitting holds up to 2.0 s, with the reason written into the spec and
printed in every report. The holds are the subject. They are not dead air, and they are not hidden.

**5. Slow and retained beats fast and abandoned.** The retention argument is blunt: "one 10M-view video
with 70 % retention is worth more than ten 1M-view videos at 40 %." So the count is paced at **7.7
weeks a second** — fast enough to feel relentless, slow enough that a viewer can still count — rather
than a blur of numbers that looks impressive and means nothing.

## what was deliberately not taken

- **No mascots.** Kurzgesagt uses ducks as a warm counterweight. Our audience is the systems
  professional; warmth here comes from precision, not characters.
- **No watercolour, no texture, no painterly grade.** The Egg's look is theirs. Ours is the technical
  sheet (`DESIGN.md`) and it must stay identical to every other episode.
- **No camera moves, no parallax, no transitions.** Their pieces carry the eye with constant camera
  motion. Ours carries it with state changes only, because a camera that moves without a reason is the
  single most frequent note on this project.
- **No borrowing of the runtime.** The Egg is eight minutes. The transferable part is restraint at any
  length, not the length.

## what the piece argues

Large power transformers average **128 weeks** (Wood Mackenzie Q2 2025, range 80–210); generator
step-ups passed **160 weeks** by Q1 2026; data-centre build cycles run **under 18 months**. So the
transformer queue, not the building, is the binding constraint. The scripts, the trims and the sources
live in `t01-transformer-wait.spec.json`, under `lines` and `sources`.
