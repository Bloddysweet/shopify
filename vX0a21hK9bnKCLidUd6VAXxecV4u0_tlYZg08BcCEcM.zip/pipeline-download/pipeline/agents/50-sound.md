# agent · sound

**Owns:** the voice and its placement.
**Delivers:** a mixed track, each line trimmed to speech and placed on its word.

**Machine checks:** mean level between −24 and −12 dB, peak ≤ −1 dBFS, no silent tail, no line starting
inside a silence it does not belong to.
**May not:** ship a track longer than the picture, or a line placed before the moment it describes.
