# PAGE.md — what a drawing has to be, to be measured

A shot is a **function of time**, not an animation that plays. The gates open the page, ask it what
it looks like at any second, and compare that against the spec. That only works if the page answers.

No framework, no build step, no dependency. One html file per shot, with these six hooks on `window`.

| hook | returns | used by |
|---|---|---|
| `__ready` | `true` once fonts are loaded and a frame can be drawn | every gate |
| `__total()` | the length of the shot in seconds, as a number | every gate |
| `__draw(t)` | puts the page in its state at time `t` | render, audit, boxes |
| `__boxesAt(t)` | `[{s, x0, y0, x1, y1}]` — every text box visible at `t`, in page pixels | frame, figures |
| `__audit(t)` | `{objects:[{name,parent,serves,x0,y0,x1,y1}], texts, textBoxes, whitelist}` | scene, figures |
| `__cam(t)` | `{view, z, xc}` — optional, for shots that move the camera | motion |

`__draw` must be **stateless**: `draw(t)` twice in a row, or backwards, must give the same page as
`draw(t)` once. The gates sample at 0.1 s and the renderer walks 30 frames a second; a page that keeps
its own state cannot be sampled or rendered.

## The three things that make it measurable

**1. Every drawn thing carries `data-name`, `data-parent` and `data-serves`.**
The scene gate reads those to answer "is this object allowed, and which line is it for". An object
with no `data-serves` is an object nobody asked for.

```html
<g data-name="rack" data-parent="root" data-serves="l1"> … </g>
```

**2. Visibility is `opacity`, on the element or on a parent.**
Both gates compute effective opacity by walking up the tree and stopping below 0.06. So a group can
be faded as a unit, and nothing needs to be added or removed from the dom to appear.

```js
const op = (n, v) => n.setAttribute('opacity', v < 0.004 ? 0 : v.toFixed(3));
```

**3. Text is `text` elements, and the words are fragments.**
The frame gate measures every visible `text` box against the safe box in the spec. Anything that is
not a `text` element is not text, and will not be measured — which is not a loophole, it is a defect
waiting for the reading gate.

## The template

`pipeline/templates/screen.html` is a working page that satisfies all of this, with one state change
so it is not a still. `node pipeline/run.mjs new <shotDir>` copies it, writes the matching spec, and
leaves a ledger. Everything after that is drawing.

## Timing

Nothing in the page may invent a number that is also in the spec. The page's `TOTAL` and the spec's
`duration` are checked against each other by the contract gate, because the mix, the render length and
the count all follow the spec.
