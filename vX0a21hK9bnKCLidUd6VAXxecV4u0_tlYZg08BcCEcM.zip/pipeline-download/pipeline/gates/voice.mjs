/* pipeline/gates/voice.mjs — the gate on the words themselves.

   Everything below this is expensive: a drawing, a mix, a render. A line that uses a banned word,
   runs to nine words, repeats an earlier line, or states a number nothing on record supports is
   cheap to fix now and expensive to find later. The standing bans are a house rule, so they are
   enforced here rather than remembered.

   Checks:
     · a banned word, from the list in lib/ladder-adjacent house style (utilise, leverage, …)
     · a line longer than 16 spoken words (a spoken line is a sentence; the 2–3 word rule is for text)
     · a line repeated from an earlier one
     · a number in a line with no entry in spec.sources whose claim carries the same figure
     · a line placed before the previous line has finished (the mix cannot overlap a voice)
*/

import { F, verdict } from './lib.mjs';
import { numbersIn } from './figures.mjs';

export const BANNED = ['utilise', 'utilize', 'leverage', 'performant', 'mechanism',
  'subsequently', 'thus', 'hence', 'in order to', 'utilization', 'utilization'];

export async function runVoiceGate(spec) {
  const findings = [];
  const lines = spec.lines || [];
  const maxWords = 16;
  const last = lines[lines.length - 1];
  const sources = spec.sources || [];

  const seen = new Map();
  let prevEnd = -Infinity;

  for (const l of lines) {
    const text = String(l.text || '');
    const low = text.toLowerCase();

    for (const b of BANNED) {
      if (new RegExp(`\\b${b.replace(/ /g, '\\s+')}\\b`).test(low))
        findings.push(F('1-voice', `line ${l.v} uses "${b}"`, 'say the plain word instead — the ban list is a house rule, not a preference', { line: l.v }));
    }

    const words = text.replace(/[^\w'\s-]/g, ' ').trim().split(/\s+/).filter(Boolean);
    if (words.length > maxWords)
      findings.push(F('1-voice', `line ${l.v} is ${words.length} words long: "${text}"`,
        `a spoken line is a sentence, but a short one — ${maxWords} words is the ceiling for this shot`, { line: l.v }));

    if (!/\S/.test(text) || words.length < 2)
      findings.push(F('1-voice', `line ${l.v} has almost no words in it`, 'a line exists to say something', { line: l.v }));

    const key = low.replace(/[^\w\s]/g, '').trim();
    const loopsBack = spec.loop && l === last && seen.size > 0 && seen.has(key) && seen.get(key) === lines[0].v;
    if (seen.has(key) && !loopsBack)
      findings.push(F('1-voice', `line ${l.v} says the same thing as ${seen.get(key)}`, 'a repeat costs a second of screen time and earns nothing', { line: l.v }));
    else seen.set(key, l.v);

    /* every number in the voice traces to a source, or it is an invention */
    for (const n of numbersIn(text)) {
      const backed = sources.some(s =>
        String(s.claim || '').includes(String(n.value)) ||
        (Array.isArray(s.numbers) && s.numbers.some(x => Math.abs(x - n.value) < 1e-9)));
      if (!backed && !(spec.figure_waivers || []).some(w => w.line === l.v && Number(w.number) === n.value))
        findings.push(F('1-voice', `line ${l.v} says ${n.value}, and no entry in spec.sources carries it`,
          'add the claim and its url — or the arithmetic, in sources[].numbers + derivation — or take the number out',
          { line: l.v, number: n.value }));
    }

    /* the mix plays one voice at a time */
    const dur = (l.trim?.[1] ?? 0) - (l.trim?.[0] ?? 0);
    if (typeof l.in === 'number' && l.in < prevEnd - 0.02)
      findings.push(F('1-voice', `line ${l.v} starts at ${l.in}s, before the previous line ends at ${prevEnd.toFixed(2)}s`,
        'two voices cannot occupy the same second', { line: l.v }));
    prevEnd = Math.max(prevEnd, (l.in ?? 0) + dur);

    if (typeof l.in === 'number' && spec.duration && l.in + dur > spec.duration + 0.05)
      findings.push(F('1-voice', `line ${l.v} ends at ${(l.in + dur).toFixed(2)}s, after the shot ends at ${spec.duration}s`,
        'the last word has to land inside the shot', { line: l.v }));
  }

  const report = [
    `${lines.length} line(s), ${lines.reduce((a, l) => a + String(l.text || '').split(/\s+/).filter(Boolean).length, 0)} word(s)`,
    `${sources.length} source(s) on record`,
    findings.length ? '' : 'no findings'
  ].join('\n');

  return verdict('voice', findings, report);
}
