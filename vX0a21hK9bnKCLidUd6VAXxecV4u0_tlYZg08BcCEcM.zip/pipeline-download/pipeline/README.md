# the line

Not one assistant doing every job and grading itself. Seven agents, one artifact each, and a gate
between every pair. An agent never sees the next agent's work as a suggestion — it sees it as an input
it either accepts or sends back with numbered findings.

```
   director      →  spec.json            (what the shot is, and why every beat exists)
       ↓                                   gate 0 · spec legal
   image         →  src/<shot>.html      (the drawing, one projection, nothing invented)
       ↓                                   gate 3 · frame     gate 4 · scene   [code]
       ↓                                   gate 4b · figures                  [code]
   image-critic  →  reading verdict      (does the picture say the sentence)    [signed]
       ↓
   motion        →  the timeline         (state changes, each with a reason)
       ↓                                   gate 6 · motion                     [code]
   motion-critic →  rhythm verdict       (does every change mean something)    [signed]
       ↓
   sound         →  the track            (trimmed to speech, placed on the word) [code]
       ↓                                   gate 9 · still   ← the user's word
   encode        →  the file             (refuses to run without the approval)
       ↓                                   gate 10 · rewatch ← the user
   user          →  locked
```

## Start a shot with one command

```
node pipeline/run.mjs new shorts/my-thing
```

That writes a legal spec (marked `scaffold: true`, which the spec gate refuses until you write the
shot), a `screen.html` that already satisfies the page contract, the four working folders and a
ledger. From there it is drawing and words, and `all` walks the line until a judgement gate stops it.

`pipeline/PAGE.md` is the contract every drawing owes the gates — six hooks, `data-name` on everything
drawn, `opacity` for visibility, and `draw(t)` as a pure function of time. A page that keeps its own
state cannot be sampled at 0.1 s or rendered frame by frame, and both of those are how this sees.

## The gates are tested

`node pipeline/run.mjs test` runs `pipeline/tests/run-tests.mjs`: sixteen cases that each break
exactly one rule, and the gate that owns that rule has to reject it with the right finding. `all` runs
the suite before it runs the line, and refuses to start if a gate has stopped catching its own case.

This is not ceremony. The figures gate found, on its first real run, that t01 says *"fifty more weeks"*
while the counter is standing on 116 — a number the voice names and the frame never reaches. Nine
earlier passes had not caught it, because nine earlier gates were not asking.

## The schema is real

`pipeline/schema/spec.schema.json` is checked by `lib/spec.mjs` on every run — required keys, types,
enums, and `additionalProperties: false`, so a misspelt key is a finding rather than a silently ignored
line. On its first run it found four inconsistencies in the two specs that had already passed every gate.

## What is code and what is judgement

| | runs | can be faked |
|---|---|---|
| **code gates** (spec, image, frame, scene, figures, motion, sound, encode) | `run.mjs` invokes them, reads exit codes and the report | no — they measure the page |
| **judgement gates** (reading, rhythm) | an agent writes a signed verdict file; `run.mjs` validates the signature and refuses anything else | only by lying in a file, which is on the record |
| **the user's gates** (still, watch) | an approval with a quote, or a rejection naming a gate | no — nothing advances without them |

A judgement gate cannot be run by the pipeline. That is deliberate: a critic that can generate its own
evidence is not a critic. `submit` rejects a verdict signed by the wrong agent, and rejects a verdict
for a stage that isn't open yet.

## Anti-cheating, built in

- **Order is enforced.** `run <stage>` refuses if any earlier stage is open.
- **A pass expires.** Every stage records a hash of the spec and of the drawing. Change either and the
  downstream passes go `↺ stale` — a "small fix" cannot quietly become a different shot.
- **Encode is blocked on the user.** `encode` refuses unless the `still` gate carries an approval quote.
- **A rejection does not restart the shot.** `reject <stage> "why"` reopens that stage and everything
  after it, and records the reason against the stage that should have caught it.

## Use

```
node pipeline/run.mjs status  ep01/shots/s04-rack-100-homes
node pipeline/run.mjs next    ep01/shots/s04-rack-100-homes
node pipeline/run.mjs run     ep01/shots/s04-rack-100-homes frame
node pipeline/run.mjs submit  ep01/shots/s04-rack-100-homes reading <verdict.json>
node pipeline/run.mjs approve ep01/shots/s04-rack-100-homes still "that's almost near to perfect"
node pipeline/run.mjs reject  ep01/shots/s04-rack-100-homes reading "the picture does not carry the number"
```

Verdict file:

```json
{ "stage": "reading", "shot": "ep01/s04-rack-100-homes", "agent": "image-critic",
  "verdict": "PASS" ,
  "summary": "one sentence",
  "evidence": ["ep01/build/v-8p0.png"],
  "findings": [ { "id": "R1", "gate": "5-reading", "line": "l3", "at": "6.45–9.24s",
                  "what": "what is wrong, in plain words",
                  "fix": "what the agent must do about it" } ] }
```

## What each shot leaves behind

```
ep01/shots/<shot>/
  <shot>.spec.json      the contract
  ledger.json           every stage, its state, its findings, its hashes, every rejection
  verdicts/<gate>.json  the signed judgement gates, kept
  reports/<gate>.txt    the code gates' raw evidence
  derived/              camera and scene configs generated from the spec
  build/, <shot>.mp4    the picture and the file
```

## Adding an agent

Only if it owns a question no other agent asks. Add it to `lib/ladder.mjs` with an `owner`, a `kind`,
and either a `run` (code) or a `brief` (judgement), and write its card in `agents/`. If it duplicates a
question already covered, it is a checklist item on the existing gate instead.
