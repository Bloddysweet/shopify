/* pipeline/gates/lib.mjs — one way to open a shot, so every gate sees the same frame.
   Before this, each tool had its own viewport, its own safe box and its own idea of "text".
   That is how three critics came to disagree about the same picture. */

import puppeteer from 'puppeteer';
import path from 'node:path';
import fs from 'node:fs';

const ROOT = path.resolve(new URL('../../', import.meta.url).pathname);

export async function openShot(spec) {
  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--force-color-profile=srgb', '--font-render-hinting=none']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: spec.frame.w, height: spec.frame.h, deviceScaleFactor: 1 });
  await page.goto('file://' + path.join(ROOT, spec.src), { waitUntil: 'load' });
  await page.waitForFunction('window.__ready===true', { timeout: 20000 });
  await page.evaluate(() => document.fonts.ready);
  const total = await page.evaluate(() => window.__total());
  return { browser, page, total, close: () => browser.close() };
}

/* the safe box is derived from the spec, always — never from a constant in a tool */
export function safeBox(spec) {
  const { w, margin, safe_b } = spec.frame;
  return { l: margin.l, r: w - margin.r, t: margin.t, b: safe_b };
}

export const sampleTimes = (total, step = 0.1) => {
  const out = [];
  for (let t = 0; t <= total + 1e-9; t += step) out.push(+t.toFixed(2));
  return out;
};

export const ROOT_DIR = ROOT;

/* a verdict is only ever this shape, whichever agent produced it */
export function verdict(stage, findings, report) {
  return { ok: findings.length === 0, findings, report };
}

export const F = (gate, what, fix, extra = {}) => ({ gate, what, fix, ...extra });

export function writeReport(shotDir, name, text) {
  const dir = path.join(shotDir, 'reports');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, `${name}.txt`), text || '');
}
